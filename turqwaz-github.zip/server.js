'use strict';
/*
 * Turqwaz ordering server.
 * Customers order from /, staff work from /admin. New orders reach every signed-in
 * screen instantly (Server-Sent Events) and every enrolled phone (Web Push, repeating).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Store, hashPassword, verifyPassword, rid, sha, limited } = require('./lib/store');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOADS = path.join(DATA_DIR, 'uploads');
const BACKUPS = path.join(DATA_DIR, 'backups');
const PUB = path.join(__dirname, 'public');
const MENU = JSON.parse(fs.readFileSync(path.join(__dirname, 'menu.json'), 'utf8'));
const SESSION_DAYS = 14;
const TRUST_PROXY = Math.max(0, Number(process.env.TRUST_PROXY) || 0); // number of reverse-proxy hops in front of us
fs.mkdirSync(UPLOADS, { recursive: true });
fs.mkdirSync(BACKUPS, { recursive: true });

const store = new Store(path.join(DATA_DIR, 'db.json'), {
  settings: {
    open: true,
    delivery: true,
    name: 'معجنات تركواز',
    phone: '07881317344',
    address: 'اليرموك، قرب شارع المسبح',
    area: 'اليرموك',
    apps: { talabat: '', bali: '' },
  },
  catalog: null, // { cats: [{id,name,img}], items: [{id,cat,name,desc,img,unit,step,price|variants}] }
  menu: {},      // sku -> { price?, off? }
  orders: [],
  reviews: [],
  admins: [],    // { username, role: owner|admin|cashier, hash }
  sessions: {},  // sha(token) -> { user, exp }
  audit: [],
  counter: 1000,
});
const db = store.data;
if (!db.catalog) {
  db.catalog = {
    cats: MENU.cats.map((c) => ({ id: c.id, name: c.name, img: '/img/' + c.img + '.jpg' })),
    items: MENU.items.map((it) => Object.assign({}, it, { img: '/img/' + it.img + '.jpg' })),
  };
  store.flush();
}
const notifier = require('./lib/notify')(db, store, (id) => db.orders.find((o) => o.id === id));

function audit(user, action, extra) {
  db.audit.push({ at: Date.now(), user: user || '-', action, extra: extra || '' });
  if (db.audit.length > 300) db.audit.splice(0, db.audit.length - 300);
  store.save();
}

/* ---------- menu helpers (catalog lives in the db, editable from the admin only) ---------- */
let BY = new Map();
function rebuild() {
  BY = new Map();
  for (const it of db.catalog.items) {
    if (it.variants) for (const v of it.variants) BY.set(it.id + ':' + v.id, { sku: it.id + ':' + v.id, item: it, label: v.label, def: v.price });
    else BY.set(it.id, { sku: it.id, item: it, label: '', def: it.price });
  }
}
rebuild();
function eff(sku) {
  const o = db.menu[sku] || {};
  return { price: typeof o.price === 'number' ? o.price : BY.get(sku).def, off: !!o.off };
}
function publicMenu(forAdmin) {
  return {
    cats: db.catalog.cats.map((c) => ({ id: c.id, name: c.name, img: c.img })),
    items: db.catalog.items.map((it) => ({
      id: it.id, cat: it.cat, name: it.name, desc: it.desc || '', img: it.img, unit: it.unit || '', step: it.step || 1,
      trial: !!it.trial && !(db.menu[it.id] && typeof db.menu[it.id].price === 'number'),
      lines: [...BY.values()].filter((s) => s.item === it).map((s) => ({ sku: s.sku, label: s.label, ...eff(s.sku), def: s.def })),
    })),
  };
}

/* ---------- admin bootstrap ---------- */
function ensureAdmins() {
  if (db.admins.length) return;
  const mk = (username, password, role) => db.admins.push({ username, role, hash: hashPassword(password) });
  const o = process.env.OWNER_USER, op = process.env.OWNER_PASS;
  if (o && op) mk(o, op, 'owner');
  else {
    const pw = rid(6);
    mk('owner', pw, 'owner');
    console.log('\n  First run: owner account created.\n  username: owner\n  password: ' + pw + '\n  Change it from the admin page.\n');
  }
  if (process.env.ADMIN2_USER && process.env.ADMIN2_PASS) mk(process.env.ADMIN2_USER, process.env.ADMIN2_PASS, 'admin');
  store.flush();
}
ensureAdmins();
const DUMMY_HASH = hashPassword(rid(8)); // equalises login timing for unknown users

/* ---------- http helpers ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
function isHttps(req) { return /https/.test(req.headers['x-forwarded-proto'] || '') || process.env.COOKIE_SECURE === '1'; }
function secure(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(self), camera=(), microphone=(), payment=(), usb=()');
  res.setHeader('Content-Security-Policy', "default-src 'none'; img-src 'self' data: blob:; style-src 'self' https://fonts.googleapis.com; style-src-attr 'unsafe-inline'; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; worker-src 'self'; manifest-src 'self'; base-uri 'none'; form-action 'self'; object-src 'none'; frame-ancestors 'none'");
  if (isHttps(req)) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}
function send(res, code, obj) {
  const h = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };
  if (code === 413 || code === 400) h.Connection = 'close';
  res.writeHead(code, h);
  res.end(JSON.stringify(obj));
}
function readRaw(req, max) {
  return new Promise((resolve, reject) => {
    let n = 0, over = false; const chunks = [];
    req.on('data', (c) => { if (over) return; n += c.length; if (n > max) { over = true; chunks.length = 0; reject(new Error('big')); } else chunks.push(c); });
    req.on('end', () => { if (!over) resolve(Buffer.concat(chunks)); });
    req.on('error', reject);
  });
}
async function readBody(req) {
  const buf = await readRaw(req, 32768);
  if (!buf.length) return {};
  const j = JSON.parse(buf.toString('utf8'));
  if (!j || typeof j !== 'object' || Array.isArray(j)) throw new Error('json');
  return j;
}
function ip(req) {
  const sock = req.socket.remoteAddress || '';
  if (!TRUST_PROXY) return sock;
  const xs = String(req.headers['x-forwarded-for'] || '').split(',').map((x) => x.trim()).filter(Boolean);
  return xs[xs.length - TRUST_PROXY] || sock; // entry appended by our own proxy, not client-supplied
}
function cookie(req, name) {
  const m = String(req.headers.cookie || '').split(/;\s*/).find((c) => c.startsWith(name + '='));
  try { return m ? decodeURIComponent(m.slice(name.length + 1)) : ''; } catch (e) { return ''; }
}
function getUser(req) {
  const t = cookie(req, 'tq_session');
  if (!t || t.length > 200) return null;
  const s = db.sessions[sha(t)];
  if (!s || s.exp < Date.now()) return null;
  const a = db.admins.find((x) => x.username === s.user);
  return a ? { username: a.username, role: a.role } : null;
}
const str = (v, max) => (typeof v === 'string' || typeof v === 'number' ? String(v) : '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f‪-‮⁦-⁩]/g, '').trim().slice(0, max);
const isUrl = (s) => /^https?:\/\/[^\s<>"']{4,300}$/i.test(String(s || '').trim());
function sameOrigin(req) {
  const o = req.headers.origin;
  if (o) { try { return new URL(o).host === req.headers.host; } catch (e) { return false; } }
  const sf = req.headers['sec-fetch-site'];
  return !sf || sf === 'same-origin' || sf === 'none';
}

/* ---------- live events to staff screens ---------- */
const clients = new Set();
function broadcast(ev, data) {
  const m = 'event: ' + ev + '\ndata: ' + JSON.stringify(data) + '\n\n';
  for (const c of clients) { try { c.write(m); } catch (e) { clients.delete(c); } }
}
setInterval(() => { for (const c of clients) { try { c.write(': ping\n\n'); } catch (e) { clients.delete(c); } } }, 25000).unref();

/* ---------- orders ---------- */
function orderForCustomer(o) {
  return {
    id: o.id, status: o.status, type: o.type, items: o.items, total: o.total, createdAt: o.createdAt,
    etaMinutes: o.etaMinutes || null, acceptedAt: o.acceptedAt || null, dueAt: o.dueAt || null,
    rejectReason: o.rejectReason || '', receivedAt: o.receivedAt || null, rated: !!o.rated,
    shopPhone: db.settings.phone, now: Date.now(),
  };
}
function findOrder(id) { return db.orders.find((o) => o.id === Number(id)); }
function authOrder(id, token) {
  const o = findOrder(id);
  if (!o || typeof token !== 'string' || !token || token.length > 80) return null;
  return sha(token) === o.tokenHash ? o : null;
}
function createOrder(body) {
  const s = db.settings;
  if (!s.open) return [409, { error: 'closed', message: 'المحل مغلق حالياً' }];
  const type = body.type === 'delivery' ? 'delivery' : 'pickup';
  if (type === 'delivery' && !s.delivery) return [409, { error: 'no_delivery', message: 'التوصيل غير متوفر حالياً' }];
  const name = str(body.name, 60), phone = str(body.phone, 20).replace(/[^\d+]/g, '');
  if (name.length < 2) return [400, { error: 'name', message: 'اكتب اسمك' }];
  if (phone.replace(/\D/g, '').length < 10 || phone.length > 16) return [400, { error: 'phone', message: 'رقم الهاتف غير صحيح' }];
  if (limited('ophone:' + phone, 5, 600e3)) return [429, { error: 'rate', message: 'طلبات كثيرة بنفس الرقم، حاول بعد قليل' }];
  if (!Array.isArray(body.items) || !body.items.length || body.items.length > 40) return [400, { error: 'items', message: 'السلة فارغة' }];
  const items = []; let total = 0;
  const seen = new Set();
  for (const r of body.items) {
    if (!r || typeof r !== 'object') return [400, { error: 'items', message: 'صنف غير صحيح' }];
    const s2 = BY.get(String(r.sku));
    const qty = Number(r.qty);
    if (!s2 || seen.has(s2.sku)) return [400, { error: 'items', message: 'صنف غير صحيح' }];
    seen.add(s2.sku);
    const step = s2.item.step || 1;
    if (!(qty > 0) || qty > 50 || Math.abs(qty / step - Math.round(qty / step)) > 1e-6) return [400, { error: 'qty', message: 'كمية غير صحيحة' }];
    const e = eff(s2.sku);
    if (e.off) return [409, { error: 'off', message: 'الصنف "' + s2.item.name + '" نفد' }];
    const t = Math.round(e.price * qty);
    items.push({ sku: s2.sku, name: s2.item.name + (s2.label ? ' (' + s2.label + ')' : ''), qty, unit: s2.item.unit || '', price: e.price, total: t });
    total += t;
  }
  let address = '', location = null;
  if (type === 'delivery') {
    address = str(body.address, 200);
    if (address.length < 5) return [400, { error: 'address', message: 'اكتب العنوان داخل ' + s.area }];
    const l = body.location && typeof body.location === 'object' ? body.location : {};
    const lat = Number(l.lat), lng = Number(l.lng);
    if (Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && (lat || lng)) {
      location = { lat: +lat.toFixed(6), lng: +lng.toFixed(6), acc: Math.round(Number(l.acc) || 0), link: 'https://www.google.com/maps?q=' + lat.toFixed(6) + ',' + lng.toFixed(6) };
    } else if (isUrl(l.link)) {
      location = { link: String(l.link).trim() };
    } else return [400, { error: 'location', message: 'حدد موقعك للتوصيل' }];
  }
  const token = rid(16);
  const o = {
    id: ++db.counter, tokenHash: sha(token), createdAt: Date.now(), type, name, phone, address, location,
    note: str(body.note, 300), items, total, status: 'new',
  };
  db.orders.push(o);
  if (db.orders.length > 3000) db.orders.splice(0, db.orders.length - 3000);
  store.save();
  const { tokenHash, ...pub } = o;
  broadcast('order', pub);
  try { notifier.newOrder(o); } catch (e) { console.error('notify', e.message); }
  return [200, { id: o.id, token }];
}
function forStaff(o) { const { tokenHash, ...r } = o; return r; }
function setStatus(o, status, extra) {
  Object.assign(o, extra || {}, { status });
  if (status !== 'new') notifier.handled(o.id);
  store.save();
  broadcast('order-update', forStaff(o));
}

/* ---------- catalog editing (staff with full rights only) ---------- */
const IMG_OK = /^\/(uploads\/[a-f0-9]{24}\.(jpg|png|webp)|img\/[a-z0-9-]+\.jpg)$/;
function cleanItem(b, ex) {
  const out = {};
  const name = str(b.name !== undefined ? b.name : ex && ex.name, 80);
  if (name.length < 2) return { err: 'اسم الصنف قصير' };
  const cat = String(b.cat !== undefined ? b.cat : ex && ex.cat);
  if (!db.catalog.cats.some((c) => c.id === cat)) return { err: 'القسم غير موجود' };
  out.name = name; out.cat = cat;
  out.desc = str(b.desc !== undefined ? b.desc : (ex && ex.desc) || '', 200);
  out.unit = str(b.unit !== undefined ? b.unit : (ex && ex.unit) || '', 12);
  const step = Number(b.step !== undefined ? b.step : (ex && ex.step) || 1);
  out.step = [1, 0.5, 0.25].includes(step) ? step : 1;
  const img = b.img !== undefined ? String(b.img) : (ex && ex.img) || '/img/logo.jpg';
  if (!IMG_OK.test(img) && img !== '/img/logo.jpg') return { err: 'صورة غير صالحة' };
  out.img = img;
  const price = (v) => { const n = Math.round(Number(v)); return n >= 0 && n <= 10000000 ? n : null; };
  if (Array.isArray(b.variants) && b.variants.length) {
    if (b.variants.length > 8) return { err: 'الحد الأقصى 8 خيارات' };
    const used = new Set(); out.variants = [];
    for (const v of b.variants) {
      const p = price(v && v.price), label = str(v && v.label, 30);
      if (p === null || !label) return { err: 'اسم وسعر كل خيار مطلوبان' };
      let id = /^[a-z0-9]{1,8}$/.test(String(v.id || '')) && !used.has(v.id) ? v.id : rid(2);
      used.add(id); out.variants.push({ id, label, price: p });
    }
  } else {
    const p = price(b.price !== undefined ? b.price : ex && ex.price);
    if (p === null) return { err: 'السعر غير صحيح' };
    out.price = p;
  }
  return { v: out };
}
function dropOverrides(item) {
  for (const k of Object.keys(db.menu)) if (k === item.id || k.startsWith(item.id + ':')) delete db.menu[k];
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  if (limited('all:' + ip(req), 3000, 60e3)) return send(res, 429, { error: 'rate', message: 'طلبات كثيرة' });
  const mutating = m === 'POST' || m === 'PUT' || m === 'DELETE';
  if (mutating && !sameOrigin(req)) return send(res, 403, { error: 'origin' });
  const isAdminPath = p.startsWith('/api/admin/');
  const user = isAdminPath && p !== '/api/admin/login' ? getUser(req) : null;
  if (isAdminPath && p !== '/api/admin/login' && !user) return send(res, 401, { error: 'auth' });
  const FULL = !!user && user.role !== 'cashier';

  /* image upload: raw bytes, checked by magic number, never trusted by name or header */
  if (m === 'POST' && p === '/api/admin/upload') {
    if (!FULL) return send(res, 403, { error: 'forbidden' });
    let buf; try { buf = await readRaw(req, 3 * 1024 * 1024); } catch (e) { return send(res, 413, { error: 'big', message: 'الصورة كبيرة (الحد 3 ميغا)' }); }
    let ext = '';
    if (buf.length > 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) ext = 'jpg';
    else if (buf.length > 12 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) ext = 'png';
    else if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') ext = 'webp';
    if (!ext) return send(res, 400, { error: 'img', message: 'الملف ليس صورة صالحة (jpg أو png أو webp)' });
    const name = rid(12) + '.' + ext;
    fs.writeFileSync(path.join(UPLOADS, name), buf, { mode: 0o600 });
    audit(user.username, 'upload', name);
    return send(res, 200, { url: '/uploads/' + name });
  }

  let body = {};
  if (mutating) {
    if (m !== 'DELETE' && !/^application\/json/.test(req.headers['content-type'] || '')) return send(res, 415, { error: 'type' });
    try { body = await readBody(req); } catch (e) { return send(res, 400, { error: 'bad_body' }); }
  }

  /* public */
  if (m === 'GET' && p === '/api/public') {
    const reviews = db.reviews.filter((r) => r.visible).slice(-30).reverse().map((r) => ({ name: r.name, stars: r.stars, text: r.text, items: r.items || [], at: r.at }));
    const all = db.reviews.filter((r) => r.visible && r.stars > 0);
    return send(res, 200, {
      settings: db.settings, menu: publicMenu(false), reviews,
      rating: all.length ? { avg: Math.round(all.reduce((t, r) => t + r.stars, 0) / all.length * 10) / 10, n: all.length } : null,
      now: Date.now(),
    });
  }
  if (m === 'POST' && p === '/api/orders') {
    if (limited('order:' + ip(req), 30, 600e3) || limited('order-all', 1500, 3600e3)) return send(res, 429, { error: 'rate', message: 'طلبات كثيرة، حاول بعد قليل' });
    const [c, r] = createOrder(body);
    return send(res, c, r);
  }
  let mm;
  if ((mm = p.match(/^\/api\/orders\/(\d+)$/)) && m === 'GET') {
    const o = authOrder(mm[1], req.headers['x-order-token']);
    return o ? send(res, 200, orderForCustomer(o)) : send(res, 404, { error: 'not_found' });
  }
  if ((mm = p.match(/^\/api\/orders\/(\d+)\/received$/)) && m === 'POST') {
    const o = authOrder(mm[1], body.token);
    if (!o) return send(res, 404, { error: 'not_found' });
    if (!['accepted', 'ready', 'completed'].includes(o.status)) return send(res, 409, { error: 'state', message: 'الطلب لم يُقبل بعد' });
    if (!o.receivedAt) setStatus(o, o.status, { receivedAt: Date.now() });
    return send(res, 200, orderForCustomer(o));
  }
  if ((mm = p.match(/^\/api\/orders\/(\d+)\/review$/)) && m === 'POST') {
    const o = authOrder(mm[1], body.token);
    if (!o) return send(res, 404, { error: 'not_found' });
    if (!o.receivedAt) return send(res, 409, { error: 'state', message: 'اضغط تم استلام الطلب أولاً' });
    if (o.rated) return send(res, 409, { error: 'dup', message: 'تم تقييم هذا الطلب' });
    const items = (Array.isArray(body.items) ? body.items : []).slice(0, 40).map((x) => ({ name: str(x && x.name, 80), stars: Math.max(0, Math.min(5, Math.round(Number(x && x.stars) || 0))) })).filter((x) => x.stars > 0);
    const stars = Math.max(0, Math.min(5, Math.round(Number(body.stars) || 0)));
    if (!stars && !items.length) return send(res, 400, { error: 'stars', message: 'اختر عدد النجوم' });
    db.reviews.push({ id: rid(6), at: Date.now(), name: str(body.name, 60) || o.name, stars: stars || Math.round(items.reduce((t, x) => t + x.stars, 0) / items.length), text: str(body.text, 400), items, orderId: o.id, visible: true });
    o.rated = true; store.save();
    return send(res, 200, { ok: true });
  }
  if (m === 'POST' && p === '/api/reviews') {
    if (limited('rev:' + ip(req), 5, 3600e3)) return send(res, 429, { error: 'rate', message: 'حاول لاحقاً' });
    if (!body.stars) return send(res, 400, { error: 'stars', message: 'اختر عدد النجوم' });
    const stars = Math.max(1, Math.min(5, Math.round(Number(body.stars) || 0)));
    db.reviews.push({ id: rid(6), at: Date.now(), name: str(body.name, 60) || 'زبون', stars, text: str(body.text, 400), items: [], visible: true });
    if (db.reviews.length > 2000) db.reviews.splice(0, db.reviews.length - 2000);
    store.save();
    return send(res, 200, { ok: true });
  }

  /* staff auth */
  if (m === 'POST' && p === '/api/admin/login') {
    const uname = str(body.username, 40).toLowerCase();
    if (limited('login:' + ip(req), 10, 600e3) || limited('loginu:' + uname, 8, 900e3)) return send(res, 429, { error: 'rate', message: 'محاولات كثيرة، انتظر 15 دقيقة' });
    const a = db.admins.find((x) => x.username === uname);
    const good = verifyPassword(String(body.password || '').slice(0, 200), a ? a.hash : DUMMY_HASH);
    if (!a || !good) { audit(uname, 'login-fail', ip(req)); return send(res, 401, { error: 'login', message: 'اسم المستخدم أو كلمة المرور غير صحيحة' }); }
    const token = rid(32);
    db.sessions[sha(token)] = { user: a.username, exp: Date.now() + SESSION_DAYS * 864e5 };
    for (const k of Object.keys(db.sessions)) if (db.sessions[k].exp < Date.now()) delete db.sessions[k];
    audit(a.username, 'login', ip(req));
    res.setHeader('Set-Cookie', 'tq_session=' + token + '; HttpOnly; SameSite=Strict; Path=/; Max-Age=' + SESSION_DAYS * 86400 + (isHttps(req) ? '; Secure' : ''));
    return send(res, 200, { username: a.username, role: a.role });
  }
  if (isAdminPath && user && !FULL) {
    const okc = (m === 'GET' && ['/api/admin/me', '/api/admin/stream', '/api/admin/state'].includes(p)) || /^\/api\/admin\/(logout|password|push\/.*|orders\/\d+\/(accept|reject|ready|complete))$/.test(p)
      || (m === 'POST' && p === '/api/admin/settings' && Object.keys(body).every((k) => k === 'open' || k === 'delivery'))
      || (m === 'POST' && p === '/api/admin/menu' && Object.keys(body).every((k) => k === 'sku' || k === 'off'));
    if (!okc) return send(res, 403, { error: 'forbidden', message: 'هذه الصلاحية للمسؤول فقط' });
  }
  if (m === 'GET' && p === '/api/admin/push/key') return send(res, 200, { key: notifier.publicKey() });
  if (m === 'POST' && p === '/api/admin/push/subscribe') {
    const ok = notifier.subscribe(body.subscription, user.username);
    return send(res, ok ? 200 : 400, { ok, devices: notifier.count() });
  }
  if (m === 'POST' && p === '/api/admin/push/unsubscribe') { notifier.unsubscribe(String(body.endpoint || '')); return send(res, 200, { ok: true }); }
  if (m === 'POST' && p === '/api/admin/push/test') {
    if (limited('pushtest:' + user.username, 6, 600e3)) return send(res, 429, { error: 'rate' });
    await notifier.test(); return send(res, 200, { ok: true, devices: notifier.count() });
  }
  if (m === 'POST' && p === '/api/admin/logout') {
    const t = cookie(req, 'tq_session'); if (t) { delete db.sessions[sha(t)]; store.save(); }
    res.setHeader('Set-Cookie', 'tq_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
    return send(res, 200, { ok: true });
  }
  if (m === 'GET' && p === '/api/admin/me') return send(res, 200, user);
  if (m === 'GET' && p === '/api/admin/stream') {
    if (clients.size >= 60) return send(res, 503, { error: 'busy' });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write('retry: 3000\n\nevent: hello\ndata: {}\n\n');
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }
  if (m === 'GET' && p === '/api/admin/state') {
    return send(res, 200, {
      me: user, settings: db.settings, menu: publicMenu(true),
      orders: db.orders.slice(-150).reverse().map(forStaff),
      reviews: db.reviews.slice(-100).reverse(),
      admins: user.role === 'owner' ? db.admins.map((a) => ({ username: a.username, role: a.role })) : undefined,
      now: Date.now(),
    });
  }
  if ((mm = p.match(/^\/api\/admin\/orders\/(\d+)\/(accept|reject|ready|complete)$/)) && m === 'POST') {
    const o = findOrder(mm[1]);
    if (!o) return send(res, 404, { error: 'not_found' });
    const act = mm[2];
    if (act === 'accept') {
      if (o.status !== 'new') return send(res, 409, { error: 'state', message: 'تمت معالجة الطلب' });
      const min = Math.round(Number(body.minutes) || 0);
      if (!(min >= 1 && min <= 240)) return send(res, 400, { error: 'minutes', message: 'حدد مدة الإنجاز' });
      const un = Array.isArray(body.unavail) ? body.unavail.map(String) : [];
      const left = o.items.filter((i) => !un.includes(i.sku));
      if (!left.length) return send(res, 400, { error: 'items', message: 'كل الأصناف غير متوفرة، ارفض الطلب بدلاً من قبوله' });
      o.items.forEach((i) => { i.unavailable = un.includes(i.sku); });
      o.total = left.reduce((a, i) => a + i.total, 0);
      const now = Date.now();
      setStatus(o, 'accepted', { etaMinutes: min, acceptedAt: now, dueAt: now + min * 60000, handledBy: user.username });
    } else if (act === 'reject') {
      if (o.status !== 'new') return send(res, 409, { error: 'state', message: 'تمت معالجة الطلب' });
      setStatus(o, 'rejected', { rejectReason: str(body.reason, 120), handledBy: user.username });
    } else if (act === 'ready') {
      if (o.status !== 'accepted') return send(res, 409, { error: 'state' });
      setStatus(o, 'ready', { readyAt: Date.now() });
    } else {
      if (!['accepted', 'ready'].includes(o.status)) return send(res, 409, { error: 'state' });
      setStatus(o, 'completed', { completedAt: Date.now() });
    }
    return send(res, 200, forStaff(o));
  }
  if (m === 'POST' && p === '/api/admin/settings') {
    const s = db.settings;
    if (typeof body.open === 'boolean') { s.open = body.open; audit(user.username, s.open ? 'open' : 'close'); }
    if (typeof body.delivery === 'boolean') s.delivery = body.delivery;
    if (body.phone !== undefined) s.phone = str(body.phone, 20).replace(/[^\d+]/g, '');
    if (body.address !== undefined) s.address = str(body.address, 120);
    if (body.apps && typeof body.apps === 'object') {
      for (const k of ['talabat', 'bali']) if (body.apps[k] !== undefined) s.apps[k] = isUrl(body.apps[k]) ? String(body.apps[k]).trim() : '';
    }
    store.save(); broadcast('settings', s);
    return send(res, 200, s);
  }
  if (m === 'POST' && p === '/api/admin/menu') {
    const sku = String(body.sku);
    if (!BY.has(sku)) return send(res, 404, { error: 'not_found' });
    const o = db.menu[sku] || (db.menu[sku] = {});
    if (body.price !== undefined) {
      if (!FULL) return send(res, 403, { error: 'forbidden' });
      const v = Number(body.price); if (!(v >= 0) || v > 10000000) return send(res, 400, { error: 'price', message: 'سعر غير صحيح' }); o.price = Math.round(v); audit(user.username, 'price', sku + '=' + o.price);
    }
    if (typeof body.off === 'boolean') o.off = body.off;
    store.save(); broadcast('menu', { sku, ...eff(sku) });
    return send(res, 200, { sku, ...eff(sku) });
  }

  /* categories and items: add/edit/delete — staff with full rights only */
  if (m === 'POST' && p === '/api/admin/cats') {
    const name = str(body.name, 40); if (name.length < 2) return send(res, 400, { error: 'name', message: 'اسم القسم قصير' });
    const img = body.img ? String(body.img) : '/img/logo.jpg';
    if (!IMG_OK.test(img)) return send(res, 400, { error: 'img', message: 'صورة غير صالحة' });
    if (db.catalog.cats.length >= 30) return send(res, 409, { error: 'limit', message: 'الحد الأقصى 30 قسماً' });
    db.catalog.cats.push({ id: 'c' + rid(3), name, img }); store.save(); audit(user.username, 'cat-add', name);
    broadcast('catalog', {}); return send(res, 200, publicMenu(true));
  }
  if ((mm = p.match(/^\/api\/admin\/cats\/(c?[a-z0-9]+)$/))) {
    const c = db.catalog.cats.find((x) => x.id === mm[1]);
    if (!c) return send(res, 404, { error: 'not_found' });
    if (m === 'POST') {
      if (body.name !== undefined) { const n = str(body.name, 40); if (n.length < 2) return send(res, 400, { error: 'name' }); c.name = n; }
      if (body.img !== undefined) { if (!IMG_OK.test(String(body.img))) return send(res, 400, { error: 'img' }); c.img = String(body.img); }
      store.save(); audit(user.username, 'cat-edit', c.id); broadcast('catalog', {}); return send(res, 200, publicMenu(true));
    }
    if (m === 'DELETE') {
      if (db.catalog.items.some((i) => i.cat === c.id)) return send(res, 409, { error: 'notempty', message: 'احذف أصناف القسم أو انقلها أولاً' });
      db.catalog.cats.splice(db.catalog.cats.indexOf(c), 1); store.save(); audit(user.username, 'cat-del', c.id);
      broadcast('catalog', {}); return send(res, 200, publicMenu(true));
    }
  }
  if (m === 'POST' && p === '/api/admin/items') {
    if (db.catalog.items.length >= 400) return send(res, 409, { error: 'limit', message: 'الحد الأقصى 400 صنف' });
    const r = cleanItem(body, null); if (r.err) return send(res, 400, { error: 'item', message: r.err });
    const it = Object.assign({ id: 'x' + rid(4) }, r.v); db.catalog.items.push(it); rebuild(); store.save();
    audit(user.username, 'item-add', it.name); broadcast('catalog', {}); return send(res, 200, publicMenu(true));
  }
  if ((mm = p.match(/^\/api\/admin\/items\/([a-z0-9-]+)$/))) {
    const it = db.catalog.items.find((x) => x.id === mm[1]);
    if (!it) return send(res, 404, { error: 'not_found' });
    if (m === 'POST') {
      const r = cleanItem(body, it); if (r.err) return send(res, 400, { error: 'item', message: r.err });
      dropOverrides(it); Object.keys(it).forEach((k) => { if (k !== 'id') delete it[k]; }); Object.assign(it, r.v); rebuild(); store.save();
      audit(user.username, 'item-edit', it.id); broadcast('catalog', {}); return send(res, 200, publicMenu(true));
    }
    if (m === 'DELETE') {
      db.catalog.items.splice(db.catalog.items.indexOf(it), 1); dropOverrides(it); rebuild(); store.save();
      audit(user.username, 'item-del', it.id); broadcast('catalog', {}); return send(res, 200, publicMenu(true));
    }
  }
  if ((mm = p.match(/^\/api\/admin\/reviews\/([a-f0-9]+)\/(hide|show|delete)$/)) && m === 'POST') {
    const i = db.reviews.findIndex((r) => r.id === mm[1]);
    if (i < 0) return send(res, 404, { error: 'not_found' });
    if (mm[2] === 'delete') db.reviews.splice(i, 1); else db.reviews[i].visible = mm[2] === 'show';
    store.save();
    return send(res, 200, { ok: true });
  }
  if (m === 'POST' && p === '/api/admin/password') {
    const a = db.admins.find((x) => x.username === user.username);
    if (limited('pw:' + user.username, 6, 600e3)) return send(res, 429, { error: 'rate' });
    if (!verifyPassword(String(body.old || ''), a.hash)) return send(res, 400, { error: 'old', message: 'كلمة المرور الحالية غير صحيحة' });
    const np = String(body.new || '');
    if (np.length < 10 || np.length > 200 || np.toLowerCase() === a.username) return send(res, 400, { error: 'short', message: 'كلمة المرور 10 أحرف على الأقل' });
    a.hash = hashPassword(np);
    const mine = sha(cookie(req, 'tq_session'));
    for (const k of Object.keys(db.sessions)) if (db.sessions[k].user === a.username && k !== mine) delete db.sessions[k];
    store.save(); audit(user.username, 'password');
    return send(res, 200, { ok: true });
  }
  if (p === '/api/admin/admins' && user.role !== 'owner') return send(res, 403, { error: 'owner_only' });
  if (m === 'GET' && p === '/api/admin/backup') {
    if (user.role !== 'owner') return send(res, 403, { error: 'owner_only' });
    const bk = { at: Date.now(), settings: db.settings, catalog: db.catalog, menu: db.menu, orders: db.orders.map(forStaff), reviews: db.reviews };
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="turqwaz-backup.json"', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify(bk));
  }
  if (m === 'POST' && p === '/api/admin/admins') {
    const username = str(body.username, 30).toLowerCase();
    if (!/^[a-z0-9_.-]{3,30}$/.test(username)) return send(res, 400, { error: 'username', message: 'اسم المستخدم إنجليزي 3 أحرف أو أكثر' });
    const pw = String(body.password || '');
    if (pw.length < 10 || pw.length > 200) return send(res, 400, { error: 'short', message: 'كلمة المرور 10 أحرف على الأقل' });
    if (db.admins.some((a) => a.username === username)) return send(res, 409, { error: 'exists', message: 'الاسم موجود' });
    if (db.admins.length >= 8) return send(res, 409, { error: 'limit', message: 'الحد الأقصى 8 حسابات' });
    db.admins.push({ username, role: body.role === 'cashier' ? 'cashier' : 'admin', hash: hashPassword(pw) }); store.save();
    audit(user.username, 'admin-add', username);
    return send(res, 200, db.admins.map((a) => ({ username: a.username, role: a.role })));
  }
  if ((mm = p.match(/^\/api\/admin\/admins\/([a-z0-9_.-]+)$/)) && m === 'DELETE') {
    const a = db.admins.find((x) => x.username === mm[1]);
    if (!a || a.role === 'owner') return send(res, 400, { error: 'bad' });
    db.admins.splice(db.admins.indexOf(a), 1);
    for (const k of Object.keys(db.sessions)) if (db.sessions[k].user === a.username) delete db.sessions[k];
    store.save(); audit(user.username, 'admin-del', a.username);
    return send(res, 200, db.admins.map((x) => ({ username: x.username, role: x.role })));
  }
  return send(res, 404, { error: 'not_found' });
}

/* ---------- static files ---------- */
function serveFile(res, file, ext, cache, extra) {
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('غير موجود'); }
    res.writeHead(200, Object.assign({ 'Content-Type': TYPES[ext], 'Cache-Control': cache, 'Content-Length': buf.length }, extra || {}));
    res.end(buf);
  });
}
function serveStatic(req, res, url) {
  let p;
  try { p = decodeURIComponent(url.pathname); } catch (e) { res.writeHead(400); return res.end(); }
  if (p.includes('\0') || p.includes('\\')) { res.writeHead(400); return res.end(); }
  if (p.startsWith('/uploads/')) {
    const n = p.slice(9);
    if (!/^[a-f0-9]{24}\.(jpg|png|webp)$/.test(n)) { res.writeHead(404); return res.end(); }
    return serveFile(res, path.join(UPLOADS, n), path.extname(n), 'public, max-age=604800, immutable', { 'Content-Security-Policy': "default-src 'none'; sandbox" });
  }
  if (p === '/') p = '/index.html';
  if (p === '/admin' || p === '/admin/') p = '/admin.html';
  const file = path.normalize(path.join(PUB, p));
  const ext = path.extname(file).toLowerCase();
  if (!file.startsWith(PUB + path.sep) || path.basename(file).startsWith('.') || !TYPES[ext]) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('غير موجود'); }
  const extra = p === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {};
  serveFile(res, file, ext, p.startsWith('/img/') ? 'public, max-age=86400' : 'no-cache', extra);
}

const server = http.createServer((req, res) => {
  secure(req, res);
  let url;
  try { url = new URL(req.url, 'http://x'); } catch (e) { res.writeHead(400); return res.end(); }
  if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  if (url.pathname.startsWith('/api/')) {
    api(req, res, url).catch((e) => { console.error(e); if (!res.headersSent) send(res, 500, { error: 'server' }); });
  } else if (req.method === 'GET' || req.method === 'HEAD') serveStatic(req, res, url);
  else { res.writeHead(405); res.end(); }
});
server.headersTimeout = 15000; server.requestTimeout = 60000; server.keepAliveTimeout = 5000; server.maxHeadersCount = 60;
server.on('clientError', (e, sock) => { try { sock.end('HTTP/1.1 400 Bad Request\r\n\r\n'); } catch (x) {} });
process.on('unhandledRejection', (e) => console.error('unhandledRejection', e));

/* daily backup of the database file (keeps 14) */
function backup() {
  try {
    store.flush();
    const f = path.join(BACKUPS, 'db-' + new Date().toISOString().slice(0, 10) + '.json');
    if (!fs.existsSync(f)) fs.copyFileSync(path.join(DATA_DIR, 'db.json'), f);
    const all = fs.readdirSync(BACKUPS).filter((x) => /^db-.*\.json$/.test(x)).sort();
    all.slice(0, Math.max(0, all.length - 14)).forEach((x) => fs.unlinkSync(path.join(BACKUPS, x)));
  } catch (e) { console.error('backup', e.message); }
}
backup(); setInterval(backup, 6 * 3600e3).unref();

if (require.main === module) server.listen(PORT, () => console.log('Turqwaz server on http://localhost:' + PORT + '  (cashier: /admin)'));
module.exports = server;
