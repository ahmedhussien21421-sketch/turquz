const { chromium } = require('playwright');
const BASE = process.env.BASE || 'http://localhost:3111';
const ok = (c, m) => { if (!c) { console.error('FAIL', m); process.exitCode = 1; } else console.log('ok  ', m); };
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' }).catch(() => chromium.launch());
  const errs = [];
  const a = await (await b.newContext({ viewport: { width: 420, height: 900 } })).newPage(); a.on('pageerror', (e) => errs.push(e.message));
  await a.goto(BASE + '/admin'); await a.fill('#u', 'owner'); await a.fill('#p', process.env.OWNER_PASS || 'TestPass123'); await a.click('button[type=submit]'); await a.waitForSelector('.tabs');
  await a.click('[data-tab=menu]');
  await a.click('[data-act=newitem]');
  await a.fill('#ed-name', 'منقوشة تجربة جديدة'); await a.fill('#ed-desc', 'وصف تجريبي'); await a.fill('#ed-price', '3250');
  await a.setInputFiles('#ed-file', 'public/img/m-lahm.jpg');
  await a.waitForTimeout(1500); console.log('UP:', (await a.textContent('.ed')).slice(-120));
  await a.waitForFunction(() => /تم رفع الصورة/.test(document.body.textContent), null, { timeout: 5000 });
  await a.click('[data-act=edsave]'); await a.waitForSelector('.panel.ed', { state: 'detached' });
  ok(/منقوشة تجربة جديدة/.test(await a.textContent('#app')), 'admin sees new item in menu list');
  const c = await (await b.newContext({ viewport: { width: 400, height: 800 } })).newPage(); c.on('pageerror', (e) => errs.push(e.message));
  await c.goto(BASE + '/'); await c.click('.tile >> nth=0');
  ok(await c.locator('text=منقوشة تجربة جديدة').count() === 1, 'customer sees new item');
  ok(await c.locator('.card img[src^="/uploads/"]').count() >= 1, 'uploaded image shown to customer');
  /* close the shop from admin */
  await a.click('[data-tab=settings]'); await a.click('[data-set=open][data-v="0"]');
  await c.reload(); await c.waitForSelector('.card');
  ok(await c.locator('[data-act=add]').count() === 0, 'closed: no add buttons');
  ok(await c.locator('.step').count() === 0, 'closed: no steppers');
  ok(/مغلقين حالياً/.test(await c.textContent('#app')), 'closed notice shown');
  await c.goto(BASE + '/#/cart'); ok(/لا يمكن اختيار أو طلب أي صنف/.test(await c.textContent('#app')), 'closed: cart page blocks ordering');
  await a.click('[data-set=open][data-v="1"]');
  /* delete the item again */
  await a.click('[data-tab=menu]'); await a.locator('[data-edit]').filter({ has: a.locator('xpath=.') }).first().waitFor();
  ok(!errs.length, 'no page errors ' + errs.join('|'));
  await a.screenshot({ path: '/tmp/admin-menu.png' });
  await b.close();
})().catch((e) => { console.error(e); process.exit(1); });
