// 100 concurrent customers: browse, order, get accepted, confirm receipt, rate. Needs server started with TRUST_PROXY=1.
const BASE = process.env.BASE || 'http://localhost:3112';
const N = Number(process.env.N) || 100;
const lat = []; let errors = 0; const errList = [];
async function call(method, path, opt = {}) {
  const t = Date.now();
  try {
    const h = Object.assign({ 'X-Forwarded-For': opt.ipaddr || '9.9.9.9' }, opt.headers || {});
    if (opt.body) h['Content-Type'] = 'application/json';
    const r = await fetch(BASE + path, { method, headers: h, body: opt.body ? JSON.stringify(opt.body) : undefined });
    const j = await r.json().catch(() => ({})); lat.push(Date.now() - t);
    if (!r.ok && !opt.allow) { errors++; errList.push(method + ' ' + path + ' ' + r.status + ' ' + JSON.stringify(j)); }
    return { s: r.status, j, h: r.headers };
  } catch (e) { errors++; errList.push(method + ' ' + path + ' ' + e.message); return { s: 0, j: {} }; }
}
(async () => {
  const lg = await call('POST', '/api/admin/login', { body: { username: 'owner', password: process.env.OWNER_PASS || 'TestPass123' }, ipaddr: '1.1.1.1' });
  const cookie = lg.h.get('set-cookie').split(';')[0];
  // cashier screen listening on the live stream
  const seen = new Set(); let streamErr = 0;
  const ctrl = new AbortController();
  fetch(BASE + '/api/admin/stream', { headers: { Cookie: cookie }, signal: ctrl.signal }).then(async (r) => {
    const rd = r.body.getReader(); const dec = new TextDecoder(); let buf = '';
    for (;;) { const { value, done } = await rd.read(); if (done) break; buf += dec.decode(value); let i;
      while ((i = buf.indexOf('\n\n')) >= 0) { const blk = buf.slice(0, i); buf = buf.slice(i + 2); if (/^event: order\n/.test(blk)) { try { seen.add(JSON.parse(blk.split('data: ')[1]).id); } catch (e) { streamErr++; } } } }
  }).catch(() => {});
  await new Promise((r) => setTimeout(r, 300));
  const pub = (await call('GET', '/api/public')).j;
  const singles = pub.menu.items.flatMap((i) => i.lines).filter((l) => !l.off);
  const t0 = Date.now();
  const customers = Array.from({ length: N }, (_, i) => (async () => {
    const ipaddr = '10.' + (i >> 8) + '.' + (i & 255) + '.7';
    await call('GET', '/api/public', { ipaddr });
    const pick = [singles[i % singles.length], singles[(i * 7 + 3) % singles.length]].filter((x, k, a) => a.findIndex((y) => y.sku === x.sku) === k);
    const del = i % 2 === 0;
    const o = await call('POST', '/api/orders', { ipaddr, body: Object.assign({ type: del ? 'delivery' : 'pickup', name: 'عميل ' + i, phone: '0770' + String(1000000 + i), note: 'ملاحظة ' + i, items: pick.map((p) => ({ sku: p.sku, qty: 1 })) }, del ? { address: 'اليرموك شارع ' + i + ' دار 3', location: { lat: 33.3, lng: 44.35, acc: 20 } } : {}) });
    if (!o.j.id) return;
    return { id: o.j.id, token: o.j.token, ipaddr };
  })());
  const placed = (await Promise.all(customers)).filter(Boolean);
  const tPlaced = Date.now() - t0;
  await new Promise((r) => setTimeout(r, 500));
  const allSeen = placed.every((o) => seen.has(o.id));
  // cashier accepts everything, with limited concurrency like a real person would be (burst of 20)
  for (let i = 0; i < placed.length; i += 20) await Promise.all(placed.slice(i, i + 20).map((o) => call('POST', '/api/admin/orders/' + o.id + '/accept', { headers: { Cookie: cookie }, body: { minutes: 20, unavail: [] }, ipaddr: '1.1.1.1' })));
  // customers poll, confirm receipt and rate
  let accepted = 0, rated = 0;
  await Promise.all(placed.map(async (o) => {
    const s = await call('GET', '/api/orders/' + o.id, { headers: { 'X-Order-Token': o.token }, ipaddr: o.ipaddr });
    if (s.j.status === 'accepted' && s.j.etaMinutes === 20) accepted++;
    await call('POST', '/api/orders/' + o.id + '/received', { body: { token: o.token }, ipaddr: o.ipaddr });
    const r = await call('POST', '/api/orders/' + o.id + '/review', { body: { token: o.token, stars: 5, text: 'ممتاز' }, ipaddr: o.ipaddr });
    if (r.j.ok) rated++;
  }));
  const st = (await call('GET', '/api/admin/state', { headers: { Cookie: cookie }, ipaddr: '1.1.1.1' })).j;
  const ids = new Set(placed.map((o) => o.id));
  const inState = st.orders.filter((o) => ids.has(o.id)).length;
  ctrl.abort();
  lat.sort((a, b) => a - b); const q = (p) => lat[Math.min(lat.length - 1, Math.floor(lat.length * p))];
  console.log(JSON.stringify({ customers: N, ordersPlaced: placed.length, placedInMs: tPlaced, cashierScreenSawAllOrdersLive: allSeen, accepted, rated, ordersInAdminState: inState, requests: lat.length, errors, p50ms: q(0.5), p95ms: q(0.95), maxMs: lat[lat.length - 1] }, null, 1));
  if (errList.length) console.log(errList.slice(0, 5));
  process.exit(errors || placed.length !== N || !allSeen || accepted !== N || rated !== N ? 1 : 0);
})();
