// Security regression tests. Server must run with TRUST_PROXY unset on BASE.
const http = require('http');
const BASE = process.env.BASE || 'http://localhost:3111';
const OWNER = [process.env.OWNER_USER || 'owner', process.env.OWNER_PASS || 'TestPass123'];
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.error('FAIL', m); } else console.log('ok  ', m); };
async function req(method, path, { body, cookie, headers, raw } = {}) {
  const h = Object.assign({}, headers || {});
  if (cookie) h.Cookie = cookie;
  let b = body;
  if (body && !raw) { h['Content-Type'] = h['Content-Type'] || 'application/json'; b = JSON.stringify(body); }
  const r = await fetch(BASE + path, { method, headers: h, body: b, redirect: 'manual' });
  let j = null; const t = await r.text(); try { j = JSON.parse(t); } catch (e) {}
  return { s: r.status, j, t, h: r.headers };
}
function rawGet(path) {
  return new Promise((res) => { const u = new URL(BASE); const q = http.request({ host: u.hostname, port: u.port, path, method: 'GET' }, (r) => { let d = ''; r.on('data', (c) => (d += c)); r.on('end', () => res({ s: r.statusCode, t: d })); }); q.on('error', () => res({ s: 0, t: '' })); q.end(); });
}
async function login(u, p) {
  const r = await req('POST', '/api/admin/login', { body: { username: u, password: p } });
  const c = (r.h.get('set-cookie') || '').split(';')[0];
  return { r, c };
}
(async () => {
  /* --- anonymous access to staff APIs --- */
  for (const [m, p] of [['GET', '/api/admin/state'], ['GET', '/api/admin/stream'], ['POST', '/api/admin/settings'], ['POST', '/api/admin/items'], ['POST', '/api/admin/upload'], ['POST', '/api/admin/orders/1001/accept'], ['GET', '/api/admin/backup'], ['POST', '/api/admin/admins']]) {
    const r = await req(m, p, { body: m === 'POST' ? {} : undefined });
    ok(r.s === 401, 'anonymous ' + m + ' ' + p + ' -> 401 (got ' + r.s + ')');
  }
  /* --- headers --- */
  const home = await req('GET', '/');
  ok(/default-src 'none'/.test(home.h.get('content-security-policy') || ''), 'strict CSP default-src none');
  ok(!/unsafe-inline/.test((home.h.get('content-security-policy') || '').replace(/style-src-attr 'unsafe-inline'/, '')), 'CSP has no unsafe-inline for scripts/styles');
  ok(home.h.get('x-frame-options') === 'DENY' && home.h.get('x-content-type-options') === 'nosniff', 'frame + nosniff headers');
  /* --- path traversal / hidden files --- */
  for (const p of ['/../server.js', '/%2e%2e/server.js', '/..%2fserver.js', '/img/../../server.js', '/%2e%2e%2fdata%2fdb.json', '/.env', '/lib/store.js', '/package.json', '/menu.json', '/uploads/../../db.json', '/uploads/..%2fdb.json']) {
    const r = await rawGet(p);
    ok(r.s !== 200 || !/require\(|"admins"|hash/.test(r.t), 'traversal blocked ' + p + ' (' + r.s + ')');
  }
  const dbf = await rawGet('/data/db.json'); ok(dbf.s === 404, 'db.json not served');
  /* --- login: wrong creds, timing-neutral message, bad types --- */
  const bad = await req('POST', '/api/admin/login', { body: { username: 'nobody', password: 'x' } });
  ok(bad.s === 401 && bad.j.error === 'login', 'wrong login -> 401');
  const bad2 = await req('POST', '/api/admin/login', { body: { username: { $ne: 1 }, password: { $ne: 1 } } });
  ok(bad2.s === 401 || bad2.s === 429, 'object injection in login rejected');
  const good = await login(...OWNER);
  ok(good.r.s === 200 && /HttpOnly/.test(good.r.h.get('set-cookie')) && /SameSite=Strict/.test(good.r.h.get('set-cookie')), 'owner login with HttpOnly+SameSite=Strict cookie');
  const C = good.c;
  /* --- CSRF: cross-origin mutation with valid cookie must fail --- */
  const csrf = await req('POST', '/api/admin/settings', { cookie: C, body: { open: false }, headers: { Origin: 'https://evil.example' } });
  ok(csrf.s === 403, 'cross-origin POST with valid session -> 403');
  const csrf2 = await req('POST', '/api/admin/settings', { cookie: C, body: { open: false }, headers: { 'Content-Type': 'text/plain' }, raw: true });
  ok(csrf2.s === 415 || csrf2.s === 403, 'non-JSON content type rejected');
  const st = await req('GET', '/api/public'); ok(st.j.settings.open === true, 'store still open after CSRF attempts');
  /* --- create cashier, check privilege limits --- */
  await req('POST', '/api/admin/admins', { cookie: C, body: { username: 'cash1', password: 'CashierPass123', role: 'cashier' } });
  const cl = await login('cash1', 'CashierPass123'); const K = cl.c;
  ok(cl.r.s === 200 && cl.r.j.role === 'cashier', 'cashier can log in');
  for (const [m, p, b] of [['POST', '/api/admin/items', { name: 'x' }], ['POST', '/api/admin/settings', { phone: '0' }], ['POST', '/api/admin/admins', { username: 'zzz', password: 'ZzzzzzPass12' }], ['GET', '/api/admin/backup'], ['POST', '/api/admin/cats', { name: 'xx' }], ['POST', '/api/admin/menu', { sku: 'd-cola', price: 1 }], ['POST', '/api/admin/upload', {}]]) {
    const r = await req(m, p, { cookie: K, body: b });
    ok(r.s === 403, 'cashier forbidden ' + m + ' ' + p + ' (got ' + r.s + ')');
  }
  const cs = await req('GET', '/api/admin/state', { cookie: K });
  ok(cs.s === 200 && cs.j.admins === undefined, 'cashier state hides accounts');
  ok(!/"hash"|tokenHash|vapid|privateKey/.test(cs.t), 'state leaks no hashes/keys');
  /* --- password policy --- */
  const weak = await req('POST', '/api/admin/admins', { cookie: C, body: { username: 'weak1', password: 'short' } });
  ok(weak.s === 400, 'short password rejected');
  /* --- orders: tampering --- */
  const menu = st.j.menu.items; const it = menu.find((i) => i.lines.length === 1 && !i.lines[0].off);
  const base = { type: 'pickup', name: 'اختبار', phone: '07700000001', items: [{ sku: it.lines[0].sku, qty: 1 }] };
  const t1 = await req('POST', '/api/orders', { body: Object.assign({}, base, { items: [{ sku: it.lines[0].sku, qty: 1, price: 1, total: 1 }], total: 1 }) });
  ok(t1.s === 200, 'order created'); 
  const adminOrder = (await req('GET', '/api/admin/state', { cookie: C })).j.orders.find((o) => o.id === t1.j.id);
  ok(adminOrder.total === it.lines[0].price, 'client-sent price ignored (server computes)');
  for (const [name, mut] of [['negative qty', { items: [{ sku: it.lines[0].sku, qty: -3 }] }], ['huge qty', { items: [{ sku: it.lines[0].sku, qty: 1e9 }] }], ['unknown sku', { items: [{ sku: 'nope', qty: 1 }] }], ['qty string', { items: [{ sku: it.lines[0].sku, qty: 'abc' }] }], ['proto pollution', { items: [{ sku: '__proto__', qty: 1 }] }], ['items not array', { items: 'x' }], ['bad phone', { phone: '12' }], ['no name', { name: '' }], ['delivery without location', { type: 'delivery', address: 'اليرموك شارع 1 دار 2' }], ['js: map link', { type: 'delivery', address: 'اليرموك شارع 1 دار 2', location: { link: 'javascript:alert(1)' } }]]) {
    const r = await req('POST', '/api/orders', { body: Object.assign({}, base, mut) });
    ok(r.s >= 400 && r.s < 500, 'rejects ' + name + ' (' + r.s + ')');
  }
  /* --- XSS payload is stored as text, and escaped by the clients (check raw API returns it unexecuted) --- */
  const xss = '<img src=x onerror=alert(1)>';
  const t2 = await req('POST', '/api/orders', { body: Object.assign({}, base, { name: xss, phone: '07700000002', note: xss }) });
  ok(t2.s === 200, 'order with HTML payload accepted as plain text');
  /* --- order token --- */
  ok((await req('GET', '/api/orders/' + t1.j.id)).s === 404, 'tracking without token -> 404');
  ok((await req('GET', '/api/orders/' + t1.j.id, { headers: { 'X-Order-Token': 'wrong' } })).s === 404, 'tracking with wrong token -> 404');
  ok((await req('GET', '/api/orders/' + t1.j.id, { headers: { 'X-Order-Token': t1.j.token } })).s === 200, 'tracking with right token -> 200');
  ok((await req('GET', '/api/orders/' + t1.j.id + '?token=' + t1.j.token)).s === 404, 'token in URL no longer accepted');
  const noleak = await req('GET', '/api/orders/' + t1.j.id, { headers: { 'X-Order-Token': t1.j.token } });
  ok(!/07700000001|tokenHash/.test(noleak.t), 'customer view has no phone/hash');
  ok((await req('POST', '/api/orders/' + t1.j.id + '/review', { body: { token: t1.j.token, stars: 5 } })).s === 409, 'cannot rate before receiving');
  /* --- closed store blocks ordering --- */
  await req('POST', '/api/admin/settings', { cookie: K, body: { open: false } });
  const closed = await req('POST', '/api/orders', { body: base }); ok(closed.s === 409 && closed.j.error === 'closed', 'closed store rejects orders');
  await req('POST', '/api/admin/settings', { cookie: K, body: { open: true } });
  /* --- uploads --- */
  const fake = await req('POST', '/api/admin/upload', { cookie: C, body: '<?php echo 1; ?>' + 'x'.repeat(40), raw: true, headers: { 'Content-Type': 'image/jpeg' } });
  ok(fake.s === 400, 'non-image upload rejected even with image content-type');
  const html = await req('POST', '/api/admin/upload', { cookie: C, body: '<script>alert(1)</script>' + ' '.repeat(40), raw: true, headers: { 'Content-Type': 'image/png' } });
  ok(html.s === 400, 'html disguised as png rejected');
  const jpg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(64, 1)]);
  const up = await req('POST', '/api/admin/upload', { cookie: C, body: jpg, raw: true, headers: { 'Content-Type': 'image/jpeg' } });
  ok(up.s === 200 && /^\/uploads\/[a-f0-9]{24}\.jpg$/.test(up.j.url), 'valid image accepted with random name');
  const big = await req('POST', '/api/admin/upload', { cookie: C, body: Buffer.concat([jpg, Buffer.alloc(3.5 * 1024 * 1024)]), raw: true, headers: { 'Content-Type': 'image/jpeg' } }).catch(() => ({ s: 0 }));
  ok(big.s === 413 || big.s === 0, 'oversize upload rejected');
  const served = await req('GET', up.j.url); ok(served.s === 200 && /sandbox/.test(served.h.get('content-security-policy') || '') && served.h.get('x-content-type-options') === 'nosniff', 'uploads served sandboxed + nosniff');
  /* --- admin item CRUD (full admin) + bad image path injection --- */
  const cat = (await req('GET', '/api/public')).j.menu.cats[0].id;
  const badimg = await req('POST', '/api/admin/items', { cookie: C, body: { name: 'تجربة', cat, price: 1000, img: '/uploads/../../etc/passwd' } }); ok(badimg.s === 400, 'item image path injection rejected');
  const ext = await req('POST', '/api/admin/items', { cookie: C, body: { name: 'تجربة', cat, price: 1000, img: 'https://evil.example/x.jpg' } }); ok(ext.s === 400, 'external image URL rejected');
  const add = await req('POST', '/api/admin/items', { cookie: C, body: { name: 'صنف جديد', cat, price: 1750, img: up.j.url } });
  ok(add.s === 200 && add.j.items.some((i) => i.name === 'صنف جديد'), 'admin can add item');
  const newItem = add.j.items.find((i) => i.name === 'صنف جديد');
  ok(newItem.lines[0].price === 1750, 'new item price saved');
  const anonAdd = await req('POST', '/api/admin/items', { body: { name: 'hack', cat, price: 1 } }); ok(anonAdd.s === 401, 'customer cannot add item');
  const del = await req('DELETE', '/api/admin/items/' + newItem.id, { cookie: C }); ok(del.s === 200 && !del.j.items.some((i) => i.id === newItem.id), 'admin can delete item');
  /* --- session invalidation on password change --- */
  const other = await login(...OWNER);
  const chg = await req('POST', '/api/admin/password', { cookie: C, body: { old: OWNER[1], new: OWNER[1] } });
  ok(chg.s === 200, 'password change accepted');
  ok((await req('GET', '/api/admin/me', { cookie: other.c })).s === 401, 'other sessions invalidated after password change');
  ok((await req('GET', '/api/admin/me', { cookie: C })).s === 200, 'current session stays valid');
  /* --- logout kills session --- */
  await req('POST', '/api/admin/logout', { cookie: K, body: {} });
  ok((await req('GET', '/api/admin/me', { cookie: K })).s === 401, 'logout invalidates session server-side');
  /* --- body size / malformed JSON --- */
  const huge = await req('POST', '/api/orders', { body: JSON.stringify({ x: 'a'.repeat(100000) }), raw: true, headers: { 'Content-Type': 'application/json' } }).catch(() => ({ s: 0 }));
  ok(huge.s === 400 || huge.s === 413 || huge.s === 0, 'oversized JSON rejected');
  const junk = await req('POST', '/api/orders', { body: '{bad json', raw: true, headers: { 'Content-Type': 'application/json' } }); ok(junk.s === 400, 'malformed JSON -> 400');
  /* --- brute force lockout (last: it locks this IP out of login) --- */
  let locked = false;
  for (let i = 0; i < 14; i++) { const r = await req('POST', '/api/admin/login', { body: { username: 'owner', password: 'wrong' + i } }); if (r.s === 429) { locked = true; break; } }
  ok(locked, 'login brute force gets rate-limited (429)');
  const afterLock = await req('POST', '/api/admin/login', { body: { username: 'owner', password: OWNER[1] } }); ok(afterLock.s === 429, 'even correct password blocked during lockout');
  console.log(fails ? '\n' + fails + ' FAILED' : '\nALL SECURITY TESTS PASSED'); process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
