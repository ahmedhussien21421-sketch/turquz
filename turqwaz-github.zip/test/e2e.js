// Run: node test/e2e.js  (server must be running on BASE, owner creds via env)
const { chromium } = require('playwright');
const BASE = process.env.BASE || 'http://localhost:3111';
const U = process.env.OWNER_USER || 'owner', P = process.env.OWNER_PASS || 'TestPass123';
const ok = (c, m) => { if (!c) { console.error('FAIL', m); process.exitCode = 1; } else console.log('ok  ', m); };
(async () => {
  const b = await chromium.launch({ executablePath: process.env.PW_CHROMIUM || '/opt/pw-browsers/chromium' }).catch(() => chromium.launch());
  const cash = await b.newContext({ viewport: { width: 420, height: 800 } }); const cp = await cash.newPage();
  const errs = []; cp.on('pageerror', (e) => errs.push(e.message));
  await cp.goto(BASE + '/admin');
  await cp.fill('#u', U); await cp.fill('#p', P); await cp.click('button[type=submit]');
  await cp.waitForSelector('.tabs');
  await cp.click('[data-act=sound]');
  ok(await cp.locator('.sound.on').count() === 1, 'cashier logged in, sound enabled');

  const cu = await b.newContext({ viewport: { width: 400, height: 800 }, geolocation: { latitude: 33.3, longitude: 44.35 }, permissions: ['geolocation'] });
  const p = await cu.newPage(); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(BASE + '/');
  ok(await p.locator('.app img.appimg').count() === 2, 'app logos shown');
  await p.click('.tile >> nth=0');
  await p.click('[data-act=add] >> nth=0'); await p.click('[data-act=add] >> nth=1');
  await p.click('.cartbar a');
  await p.click('[data-act=type][data-v=delivery]');
  await p.fill('#f-name', 'زبون تجربة'); await p.fill('#f-phone', '07701234567'); await p.fill('#f-note', 'بدون بصل');
  await p.fill('#f-addr', 'اليرموك شارع 14 دار 5');
  await p.click('[data-act=locate]'); await p.waitForSelector('.loc-ok');
  await p.check('#f-ok'); await p.click('#send');
  await p.waitForURL(/#\/order\/\d+/);
  await p.waitForSelector('.pulse', { timeout: 5000 }); ok(true, 'customer waiting for acceptance');

  await cp.waitForSelector('.call', { timeout: 5000 });
  const call = await cp.textContent('.call');
  ok(/لديك طلب جديد/.test(call) && /توصيل/.test(call), 'cashier sees incoming call with type');
  ok(!/07701234567/.test(call) && !/بدون بصل/.test(call), 'phone/notes hidden before accepting');
  await cp.locator('[data-un]').first().check();
  await cp.click('[data-min="30"]'); await cp.click('[data-act=accept]');
  await cp.waitForSelector('.call', { state: 'detached' });
  const card = await cp.textContent('.ocard');
  ok(/07701234567/.test(card) && /بدون بصل/.test(card) && /غير متوفر/.test(card), 'after accept: phone, note, unavailable shown');
  ok(await cp.locator('a[href*="google.com/maps"]').count() === 1, 'map link shown');

  await p.waitForSelector('#cd', { timeout: 8000 });
  ok(/غير متوفر/.test(await p.textContent('#app')) && /30 دقيقة/.test(await p.textContent('#app')), 'customer sees ETA + unavailable item');
  await p.click('[data-act=received]');
  await p.waitForSelector('[data-act=star]');
  await p.click('[data-act=star][data-k=all][data-v="5"]'); await p.click('[data-act=rsend]');
  await p.waitForSelector('.note.ok');
  ok(true, 'received + rating flow');
  ok(!errs.length, 'no page errors ' + errs.join('|'));
  await b.close();
})().catch((e) => { console.error(e); process.exit(1); });
