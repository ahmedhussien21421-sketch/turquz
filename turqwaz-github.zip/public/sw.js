self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('push', function (e) {
  var d = {}; try { d = e.data.json(); } catch (x) {}
  if (d.close) {
    e.waitUntil(self.registration.getNotifications({ tag: 'order-' + d.close }).then(function (l) { l.forEach(function (n) { n.close(); }); }));
    return;
  }
  e.waitUntil(self.registration.showNotification(d.title || 'طلب جديد', {
    body: d.body || '', tag: 'order-' + (d.id || 0), renotify: true, requireInteraction: true,
    vibrate: [400, 200, 400, 200, 400, 200, 400], icon: '/icon-192.png', badge: '/icon-192.png', data: { url: d.url || '/admin' }, dir: 'rtl', lang: 'ar'
  }));
});
self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (cs) {
    for (var i = 0; i < cs.length; i++) { if (cs[i].url.indexOf('/admin') >= 0 && 'focus' in cs[i]) return cs[i].focus(); }
    return self.clients.openWindow('/admin');
  }));
});
