(function () {
'use strict';
var app = document.getElementById('app');
var toastEl = document.getElementById('toast');

/* ---------- state ---------- */
function ls(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
var P = null;                    // public payload from /api/public
var LINE = {};                   // sku -> { item, line }
var cart = ls('tq_cart') || {};
var F = Object.assign({ type: 'pickup', name: '', phone: '', addr: '', link: '', note: '', ok: false }, ls('tq_form') || {});
F.loc = null; F.busy = false; F.locBusy = false; F.locErr = '';
var mine = ls('tq_orders') || [];
var O = null, oTimer = null, cdTimer = null, skew = 0;
var R = { stars: {}, name: F.name || '', text: '' };
var G = { name: '', stars: 0, text: '' };
var route = { v: 'home' };

/* ---------- helpers ---------- */
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function fmt(n) { return Number(n).toLocaleString('en-US') + ' د.ع'; }
function cnt(n) { return n === 1 ? 'صنف واحد' : (n <= 10 ? n + ' أصناف' : n + ' صنف'); }
function stars(n) { n = Math.max(0, Math.min(5, Math.round(n))); return '★★★★★'.slice(0, n) + '☆☆☆☆☆'.slice(0, 5 - n); }
function isUrl(s) { return /^https?:\/\/\S{4,300}$/i.test(String(s || '').trim()); }
function toast(t) { toastEl.textContent = t; toastEl.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.hidden = true; }, 3200); }
function api(path, opt) {
  opt = opt || {};
  var init = { method: opt.method || 'GET', headers: {} };
  if (opt.token) init.headers['X-Order-Token'] = opt.token;
  if (opt.body) { init.method = 'POST'; init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opt.body); }
  return fetch(path, init).then(function (r) { return r.json().then(function (j) { if (!r.ok) { var e = new Error(j.message || 'error'); e.data = j; throw e; } return j; }); });
}
function lines() {
  var out = [];
  if (P && !P.settings.open) return out; // closed: nothing can be selected
  Object.keys(cart).forEach(function (sku) {
    var x = LINE[sku]; if (!x || x.line.off) return;
    var q = cart[sku]; if (!(q > 0)) return;
    out.push({ sku: sku, item: x.item, line: x.line, q: q, p: x.line.price, t: Math.round(x.line.price * q) });
  });
  return out;
}
function total(L) { return L.reduce(function (a, l) { return a + l.t; }, 0); }
function nameOf(l) { return l.item.name + (l.line.label ? ' (' + l.line.label + ')' : ''); }
function setQ(sku, q) { q = Math.round(q * 100) / 100; if (q <= 0) delete cart[sku]; else cart[sku] = q; lsSet('tq_cart', cart); }
function saveForm() { lsSet('tq_form', { type: F.type, name: F.name, phone: F.phone, addr: F.addr, link: F.link }); }

/* ---------- load ---------- */
function load() {
  return api('/api/public').then(function (j) {
    P = j; skew = j.now - Date.now(); LINE = {};
    j.menu.items.forEach(function (it) { it.lines.forEach(function (l) { LINE[l.sku] = { item: it, line: l }; }); });
    return j;
  });
}
var PIN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>';

/* ---------- views ---------- */
function topBar() {
  if (route.v === 'home') return '';
  var r = P && P.rating;
  return '<header class="top"><button class="brand" data-act="home" aria-label="الرئيسية"><img class="logo" src="/img/logo.jpg" alt="" width="44" height="44"><span class="bn"><b>معجنات تركواز</b><small>Turqwaz</small></span></button>' + (r ? '<span class="rate-chip">★ ' + r.avg + '</span>' : '') + '</header>';
}
function appCard(name, key, url) {
  var ok = isUrl(url), inner = '<img class="appimg" src="/img/app-' + key + '.jpg" alt="تطبيق ' + name + '" width="64" height="64"><span class="at"><b>' + name + '</b><small>متواجدين باسم معجنات تركواز</small>' + (ok ? '<span class="go">افتح التطبيق ←</span>' : '') + '</span>';
  return ok ? '<a class="app" href="' + esc(url) + '" target="_blank" rel="noopener">' + inner + '</a>' : '<div class="app">' + inner + '</div>';
}
function home() {
  var s = P.settings, r = P.rating;
  var open = s.open ? '<span class="chip"><i class="g"></i>نستقبل طلباتكم الآن</span>' : '<span class="chip"><i class="r"></i>مغلقين حالياً</span>';
  var del = s.delivery ? '<span class="chip"><i class="g"></i>التوصيل متوفر حالياً إلى ' + esc(s.area) + '</span>' : '<span class="chip"><i class="a"></i>التوصيل غير متوفر حالياً</span>';
  var hero = '<section class="hero"><img class="hero-logo" src="/img/logo.jpg" alt="شعار معجنات تركواز" width="132" height="132"><h1>معجنات تركواز</h1><div class="en">Turqwaz</div><p class="tag2">معجنات · فطائر · مناقيش · بيتزا · صمون · حلويات</p><div class="chips">' + open + del + (r ? '<span class="chip">★ ' + r.avg + ' (' + r.n + ')</span>' : '') + '</div><div class="addr">' + PIN + '<span>' + esc(s.address) + '</span></div></section>';
  var last = mine[0] ? '<a class="btn block" href="#/order/' + mine[0].id + '">متابعة طلبك الأخير (#' + mine[0].id + ')</a>' : '';
  var tiles = P.menu.cats.map(function (c) {
    var n = P.menu.items.filter(function (i) { return i.cat === c.id; }).length;
    return '<button class="tile" data-act="cat" data-id="' + c.id + '"><img src="' + esc(c.img) + '" alt="" loading="lazy"><span class="tl"><b>' + esc(c.name) + '</b><small>' + cnt(n) + '</small></span></button>';
  }).join('');
  var apps = '<h2 class="st">نتواجد أيضاً على التطبيقات</h2><div class="apps">' + appCard('طلبات', 'talabat', s.apps.talabat) + appCard('بلي', 'bali', s.apps.bali) + '</div><p class="muted sm" style="margin:8px 0 0">ابحث عن «معجنات تركواز» داخل التطبيق.</p>';
  var rv = P.reviews.slice(0, 8).map(function (x) {
    var its = (x.items || []).map(function (i) { return esc(i.name) + ' ' + stars(i.stars); }).join(' · ');
    return '<div class="rv"><div class="rvh"><b>' + esc(x.name) + '</b><span class="stars">' + stars(x.stars) + '</span></div>' + (x.text ? '<p>' + esc(x.text) + '</p>' : '') + (its ? '<small class="muted">' + its + '</small>' : '') + '</div>';
  }).join('');
  var gstars = ''; for (var n = 1; n <= 5; n++) gstars += '<button class="' + (n <= G.stars ? 'on' : '') + '" data-act="gstar" data-v="' + n + '" aria-label="' + n + ' من 5">★</button>';
  var comments = '<h2 class="st">آراء الزبائن</h2>' + (rv ? '<div class="list">' + rv + '</div>' : '<p class="muted">لا توجد تقييمات بعد. كن أول من يشاركنا رأيه.</p>')
    + '<div class="panel" style="margin-top:12px"><b>أضف تعليقك وتقييمك</b><div class="starin">' + gstars + '</div>'
    + '<div class="field"><label for="g-name">الاسم</label><input type="text" id="g-name" data-f="gname" maxlength="60" value="' + esc(G.name) + '"></div>'
    + '<div class="field"><label for="g-text">تعليقك</label><textarea id="g-text" data-f="gtext" maxlength="400">' + esc(G.text) + '</textarea></div>'
    + '<button class="btn primary" data-act="gsend">إرسال التعليق</button></div>';
  var foot = '<div class="foot"><div class="addr2">' + PIN + '<span>' + esc(s.address) + '</span></div><div>التوصيل لمنطقة ' + esc(s.area) + ' فقط.</div>' + (s.phone ? '<div>رقم المحل: <b>' + esc(s.phone) + '</b></div>' : '') + '</div>';
  return hero + last + '<h2 class="st">اختر القسم</h2><div class="tiles">' + tiles + '</div>' + apps + comments + foot;
}
function ctrl(l, it) {
  if (l.off) return '<span class="tag">نفد</span>';
  if (!P.settings.open) return '<span class="tag">مغلقين حالياً</span>';
  var q = cart[l.sku] || 0;
  if (!q) return '<button class="btn add sm" data-act="add" data-sku="' + esc(l.sku) + '"' + (P.settings.open ? '' : ' disabled') + '>أضف</button>';
  return '<div class="step"><button data-act="dec" data-sku="' + esc(l.sku) + '" aria-label="إنقاص">−</button><output>' + q + '</output><button data-act="inc" data-sku="' + esc(l.sku) + '" aria-label="زيادة">+</button></div>';
}
function card(it) {
  var ls_ = it.lines.map(function (l) {
    return '<div class="line"><div class="lb">' + (l.label ? '<span>' + esc(l.label) + '</span>' : '') + '<span class="pr">' + fmt(l.price) + (it.unit ? ' <small>/ ' + esc(it.unit) + '</small>' : '') + '</span></div>' + ctrl(l, it) + '</div>';
  }).join('');
  var allOff = it.lines.every(function (l) { return l.off; });
  return '<article class="card' + (allOff ? ' off' : '') + '"><img class="ph" src="' + esc(it.img) + '" alt="' + esc(it.name) + '" loading="lazy"><div class="info"><h3>' + esc(it.name) + '</h3><p>' + esc(it.desc) + '</p></div><div class="lines">' + ls_ + '</div></article>';
}
function catView() {
  var c = P.menu.cats.filter(function (x) { return x.id === route.id; })[0] || P.menu.cats[0];
  var items = P.menu.items.filter(function (i) { return i.cat === c.id; });
  return '<div class="bar"><button class="btn ghost sm" data-act="home">→ الرجوع</button><div><h2 class="st">' + esc(c.name) + '</h2><small class="muted">' + cnt(items.length) + '</small></div></div>'
    + (P.settings.open ? '' : '<div class="note">مغلقين حالياً، لا يمكن إضافة أصناف للسلة الآن.</div>')
    + '<div class="list" style="margin-top:12px">' + items.map(card).join('') + '</div>';
}
function cartBar() {
  var L = lines(); if (!L.length || (route.v !== 'home' && route.v !== 'cat')) return '';
  return '<div class="cartbar"><a class="btn primary wide" href="#/cart"><span>عرض السلة (' + L.length + ')</span><b>' + fmt(total(L)) + '</b></a></div>';
}
function missing() {
  var s = P.settings, m = [];
  if (!s.open) m.push('المحل مغلق حالياً');
  if (!lines().length) m.push('السلة فارغة');
  if (F.name.trim().length < 2) m.push('الاسم');
  if (F.phone.replace(/\D/g, '').length < 10) m.push('رقم الهاتف');
  if (F.type === 'delivery') {
    if (!s.delivery) m.push('التوصيل غير متوفر حالياً');
    if (F.addr.trim().length < 5) m.push('العنوان');
    if (!(F.loc || isUrl(F.link))) m.push('تحديد الموقع');
    if (!F.ok) m.push('تأكيد أن العنوان داخل ' + s.area);
  }
  return m;
}
function cartView() {
  var s = P.settings, L = lines();
  var back = '<div class="bar"><a class="btn ghost sm" href="#/">→ القائمة</a><h2 class="st">السلة</h2></div>';
  if (!P.settings.open) return back + '<div class="panel"><p style="margin:0"><b>مغلقين حالياً.</b> لا يمكن اختيار أو طلب أي صنف في هذا الوقت، نستقبل طلباتكم فور فتح المحل.</p><a class="btn primary" href="#/">الرجوع للقائمة</a></div>';
  if (!L.length) return back + '<div class="panel"><p style="margin:0">السلة فارغة. اختر قسماً وأضف ما يعجبك.</p><a class="btn primary" href="#/">تصفح القائمة</a></div>';
  var items = L.map(function (l) {
    return '<div class="ci"><div><b>' + esc(nameOf(l)) + '</b><div class="muted sm">' + fmt(l.p) + (l.item.unit ? ' / ' + esc(l.item.unit) : '') + ' · ' + fmt(l.t) + '</div></div><div class="step"><button data-act="dec" data-sku="' + esc(l.sku) + '" aria-label="إنقاص">−</button><output>' + l.q + '</output><button data-act="inc" data-sku="' + esc(l.sku) + '" aria-label="زيادة">+</button></div></div>';
  }).join('');
  var dl = F.type === 'delivery' && s.delivery;
  var locBox = F.loc
    ? '<div class="loc-ok">تم تحديد موقعك (دقة تقريبية ' + F.loc.acc + ' متر) · <a href="https://www.google.com/maps?q=' + F.loc.lat + ',' + F.loc.lng + '" target="_blank" rel="noopener">عرض على الخريطة</a></div>'
    : '<small>' + esc(F.locErr || 'اضغط الزر وسمح للمتصفح بتحديد موقعك حتى يصلك السائق.') + '</small>';
  var delivery = dl
    ? '<div class="field"><label for="f-addr">العنوان داخل ' + esc(s.area) + '</label><input type="text" id="f-addr" data-f="addr" maxlength="200" value="' + esc(F.addr) + '" placeholder="المحلة، الشارع، رقم الدار، أقرب نقطة دالة" autocomplete="street-address"></div>'
      + '<div class="field"><label>موقعك على الخريطة</label><button class="btn" data-act="locate"' + (F.locBusy ? ' disabled' : '') + '>' + (F.locBusy ? 'جاري التحديد…' : (F.loc ? 'إعادة تحديد موقعي' : 'تحديد موقعي الآن')) + '</button>' + locBox + '</div>'
      + (F.loc ? '' : '<div class="field"><label for="f-link">أو الصق رابط موقعك من خرائط كوكل</label><input type="url" id="f-link" data-f="link" value="' + esc(F.link) + '" dir="ltr" placeholder="https://maps.app.goo.gl/..."></div>')
      + '<label class="chk" for="f-ok"><input type="checkbox" id="f-ok" data-f="ok"' + (F.ok ? ' checked' : '') + '> أؤكد أن عنواني داخل منطقة ' + esc(s.area) + '</label>'
    : '';
  return back + '<div class="panel"><div>' + items + '<div class="tot"><span>المجموع</span><span>' + fmt(total(L)) + '</span></div></div></div>'
    + '<h2 class="st">طريقة الاستلام</h2><div class="panel"><div class="seg"><button data-act="type" data-v="pickup" class="' + (F.type === 'pickup' || !s.delivery ? 'on' : '') + '">استلام من المحل</button><button data-act="type" data-v="delivery" class="' + (dl ? 'on' : '') + '"' + (s.delivery ? '' : ' disabled') + '>توصيل إلى ' + esc(s.area) + '</button></div>'
    + (s.delivery ? '' : '<div class="note">التوصيل غير متوفر حالياً، يمكنك الاستلام من المحل.</div>')
    + '<div class="field"><label for="f-name">الاسم</label><input type="text" id="f-name" data-f="name" maxlength="60" value="' + esc(F.name) + '" autocomplete="name"></div>'
    + '<div class="field"><label for="f-phone">رقم هاتفك</label><input type="tel" id="f-phone" data-f="phone" value="' + esc(F.phone) + '" inputmode="tel" dir="ltr" placeholder="07xxxxxxxxx" autocomplete="tel"></div>'
    + delivery
    + '<div class="field"><label for="f-note">ملاحظات (اختياري)</label><textarea id="f-note" data-f="note" maxlength="300">' + esc(F.note) + '</textarea></div></div>'
    + '<div style="margin-top:16px"><button class="btn primary wide" id="send" data-act="send"><span>إرسال الطلب للمحل</span><b>' + fmt(total(L)) + '</b></button><p class="miss" id="miss" role="status"></p></div>';
}
function updateSend() {
  var b = document.getElementById('send'); if (!b) return;
  var m = missing(); b.setAttribute('aria-disabled', m.length ? 'true' : 'false');
  var ms = document.getElementById('miss'); if (ms && !F.busy) ms.textContent = m.length ? 'ناقص: ' + m.join('، ') : '';
}
var STEP = { new: 0, accepted: 1, ready: 2, completed: 3 };
function orderView() {
  var back = '<div class="bar"><a class="btn ghost sm" href="#/">→ الرئيسية</a><h2 class="st">طلبك #' + route.id + '</h2></div>';
  if (!O) return back + '<div class="panel"><p style="margin:0">جاري تحميل الطلب…</p></div>';
  var o = O, s = P ? P.settings : {};
  var head;
  if (o.status === 'rejected') {
    head = '<div class="status bad"><h2>عذراً، لم يتم قبول الطلب</h2>' + (o.rejectReason ? '<div>' + esc(o.rejectReason) + '</div>' : '') + '<div class="sm">يمكنك التواصل مع المحل: <b>' + esc(o.shopPhone) + '</b></div></div>';
  } else if (o.status === 'new') {
    head = '<div class="status"><div class="pulse"></div><h2>بانتظار قبول المحل</h2><div class="muted">ابقَ في هذه الصفحة، سنخبرك فور قبول طلبك.</div><div class="sm muted" id="slow" hidden>تأخر الرد؟ تواصل مع المحل: <b>' + esc(o.shopPhone) + '</b></div></div>';
  } else if (o.status === 'accepted') {
    head = '<div class="status ok"><h2>تم قبول طلبك</h2><div>الوقت المتوقع للجاهزية</div><div class="big" id="cd">--:--</div><div class="sm">المدة المحددة: ' + o.etaMinutes + ' دقيقة</div></div>';
  } else if (o.status === 'ready') {
    head = '<div class="status ok"><h2>' + (o.type === 'delivery' ? 'طلبك جاهز وفي الطريق إليك' : 'طلبك جاهز، تفضل بالاستلام') + '</h2></div>';
  } else {
    head = '<div class="status ok"><h2>' + (o.type === 'delivery' ? 'تم توصيل الطلب' : 'تم تسليم الطلب') + '</h2></div>';
  }
  var tl = '';
  if (o.status !== 'rejected') {
    var cur = STEP[o.status] || 0, labs = ['تم الإرسال', 'تم القبول', 'جاهز', 'تم التسليم'];
    tl = '<div class="timeline">' + labs.map(function (t, i) { return '<span class="' + (i <= cur ? 'on' : '') + '">' + t + '</span>'; }).join('') + '</div>';
  }
  var sum = '<div class="panel" style="margin-top:12px"><b>' + (o.type === 'delivery' ? 'توصيل' : 'استلام من المحل') + '</b>' + o.items.map(function (i) { return '<div class="rvh"' + (i.unavailable ? ' style="text-decoration:line-through;opacity:.6"' : '') + '><span>' + esc(i.name) + ' × ' + i.qty + (i.unit ? ' ' + esc(i.unit) : '') + (i.unavailable ? ' (غير متوفر)' : '') + '</span><span>' + fmt(i.total) + '</span></div>'; }).join('') + '<div class="tot"><span>المجموع</span><span>' + fmt(o.total) + '</span></div></div>';
  var act = '';
  if (['accepted', 'ready', 'completed'].indexOf(o.status) >= 0 && !o.receivedAt) act = '<button class="btn primary block" data-act="received">تم استلام الطلب</button>';
  if (o.receivedAt && !o.rated) {
    var rows = [{ k: 'all', label: 'تقييمك العام' }].concat(o.items.map(function (i, n) { return { k: 'i' + n, label: i.name }; }));
    act = '<h2 class="st">قيّم طلبك</h2><div class="panel">' + rows.map(function (r) {
      var v = R.stars[r.k] || 0, b = '';
      for (var n = 1; n <= 5; n++) b += '<button class="' + (n <= v ? 'on' : '') + '" data-act="star" data-k="' + r.k + '" data-v="' + n + '" aria-label="' + n + ' من 5">★</button>';
      return '<div class="rrow"><b>' + esc(r.label) + '</b><div class="starin">' + b + '</div></div>';
    }).join('') + '<div class="field"><label for="r-name">اسمك</label><input type="text" id="r-name" data-f="rname" maxlength="60" value="' + esc(R.name) + '"></div><div class="field"><label for="r-text">تعليقك</label><textarea id="r-text" data-f="rtext" maxlength="400">' + esc(R.text) + '</textarea></div><button class="btn primary" data-act="rsend">إرسال التقييم</button></div>';
  }
  if (o.rated) act = '<div class="note ok" style="margin-top:12px">شكراً لتقييمك، نسعد بخدمتك دائماً.</div>';
  return back + head + tl + sum + act;
}

/* ---------- render / routing ---------- */
function body() {
  if (!P) return '<p class="muted" style="padding:40px 0;text-align:center">جاري التحميل…</p>';
  if (route.v === 'cat') return catView();
  if (route.v === 'cart') return cartView();
  if (route.v === 'order') return orderView();
  return home();
}
function render(keep) {
  var y = window.scrollY;
  app.innerHTML = topBar() + body() + cartBar();
  if (route.v === 'cart') updateSend();
  if (route.v === 'order') tickCountdown();
  window.scrollTo(0, keep ? y : 0);
}
function parse() {
  var h = location.hash.replace(/^#/, ''), m;
  if ((m = h.match(/^\/c\/([\w-]+)$/))) return { v: 'cat', id: m[1] };
  if (h === '/cart') return { v: 'cart' };
  if ((m = h.match(/^\/order\/(\d+)$/))) return { v: 'order', id: Number(m[1]) };
  return { v: 'home' };
}
function go(h) { if (location.hash === '#' + h || (h === '/' && !location.hash)) { route = parse(); render(false); } else location.hash = h; }
function onRoute() {
  route = parse();
  clearInterval(oTimer); clearInterval(cdTimer); O = null;
  if (route.v === 'order') { fetchOrder(); oTimer = setInterval(fetchOrder, 4000); cdTimer = setInterval(tickCountdown, 1000); }
  else if (route.v === 'home' || route.v === 'cat') { load().then(function () { render(true); }).catch(function () {}); }
  render(false);
}
window.addEventListener('hashchange', onRoute);

/* ---------- order tracking ---------- */
function tokenFor(id) { var m = mine.filter(function (x) { return x.id === id; })[0]; return m ? m.token : ''; }
function fetchOrder() {
  var id = route.id;
  api('/api/orders/' + id, { token: tokenFor(id) }).then(function (o) {
    if (route.v !== 'order' || route.id !== id) return;
    skew = o.now - Date.now();
    var changed = !O || JSON.stringify(strip(O)) !== JSON.stringify(strip(o));
    O = o;
    if (changed) { var y = window.scrollY; app.innerHTML = topBar() + body() + cartBar(); tickCountdown(); window.scrollTo(0, y); }
    if (o.rated || o.status === 'rejected') clearInterval(oTimer);
  }).catch(function () {
    if (!O) { app.innerHTML = topBar() + '<div class="bar"><a class="btn ghost sm" href="#/">→ الرئيسية</a></div><div class="note bad">لا نجد هذا الطلب على هذا الجهاز.</div>'; clearInterval(oTimer); }
  });
}
function strip(o) { var c = Object.assign({}, o); delete c.now; return c; }
function tickCountdown() {
  if (!O) return;
  var el = document.getElementById('cd');
  if (el && O.dueAt) {
    var left = Math.round((O.dueAt - (Date.now() + skew)) / 1000);
    if (left <= 0) { el.textContent = 'حان الموعد'; }
    else { var m = Math.floor(left / 60), s = left % 60; el.textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s; }
  }
  var slow = document.getElementById('slow');
  if (slow && O.status === 'new') slow.hidden = (Date.now() + skew) - O.createdAt < 5 * 60000;
}

/* ---------- actions ---------- */
function locate() {
  if (!navigator.geolocation) { F.locErr = 'متصفحك لا يدعم تحديد الموقع، الصق رابط موقعك.'; render(true); return; }
  F.locBusy = true; F.locErr = ''; render(true);
  navigator.geolocation.getCurrentPosition(function (p) {
    F.loc = { lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy) };
    F.locBusy = false; render(true);
  }, function () {
    F.locBusy = false; F.locErr = 'تعذر تحديد الموقع. فعّل خدمة الموقع للمتصفح أو الصق رابط موقعك.'; render(true);
  }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}
function submit() {
  var m = missing(); if (m.length) { updateSend(); return; }
  var body = { type: F.type, name: F.name.trim(), phone: F.phone.trim(), note: F.note.trim(), items: lines().map(function (l) { return { sku: l.sku, qty: l.q }; }) };
  if (F.type === 'delivery') { body.address = F.addr.trim(); body.location = F.loc ? { lat: F.loc.lat, lng: F.loc.lng, acc: F.loc.acc } : { link: F.link.trim() }; }
  F.busy = true; var ms = document.getElementById('miss'); if (ms) ms.textContent = 'جاري الإرسال…';
  api('/api/orders', { body: body }).then(function (r) {
    F.busy = false; saveForm();
    mine.unshift({ id: r.id, token: r.token }); mine = mine.slice(0, 20); lsSet('tq_orders', mine);
    cart = {}; lsSet('tq_cart', cart); R = { stars: {}, name: F.name, text: '' };
    location.hash = '#/order/' + r.id;
  }).catch(function (e) {
    F.busy = false; var m2 = document.getElementById('miss'); if (m2) m2.textContent = e.message || 'تعذر الإرسال، حاول مرة ثانية';
    if (e.data && (e.data.error === 'off' || e.data.error === 'closed' || e.data.error === 'no_delivery')) load().then(function () { render(true); });
  });
}
app.addEventListener('click', function (e) {
  var t = e.target.closest('[data-act]'); if (!t) return;
  var a = t.dataset.act, sku = t.dataset.sku, x = LINE[sku];
  if (a === 'home') go('/');
  else if (a === 'cat') go('/c/' + t.dataset.id);
  else if (a === 'add') { if (P.settings.open && x && !x.line.off) { setQ(sku, x.item.step || 1); render(true); } }
  else if (a === 'inc') { if (x && P.settings.open) { setQ(sku, (cart[sku] || 0) + (x.item.step || 1)); render(true); } }
  else if (a === 'dec') { if (x && P.settings.open) { setQ(sku, (cart[sku] || 0) - (x.item.step || 1)); render(true); } }
  else if (a === 'type') { if (t.dataset.v === 'delivery' && !P.settings.delivery) return; F.type = t.dataset.v; saveForm(); render(true); }
  else if (a === 'locate') locate();
  else if (a === 'send') { if (!F.busy && P.settings.open) submit(); }
  else if (a === 'received') {
    t.disabled = true;
    api('/api/orders/' + route.id + '/received', { body: { token: tokenFor(route.id) } }).then(function (o) { O = o; render(true); }).catch(function (er) { t.disabled = false; toast(er.message || 'تعذر التنفيذ'); });
  }
  else if (a === 'star') { R.stars[t.dataset.k] = Number(t.dataset.v); render(true); }
  else if (a === 'rsend') {
    if (!Object.keys(R.stars).length) { toast('اختر عدد النجوم أولاً'); return; }
    var its = []; O.items.forEach(function (i, n) { if (R.stars['i' + n]) its.push({ name: i.name, stars: R.stars['i' + n] }); });
    t.disabled = true;
    api('/api/orders/' + route.id + '/review', { body: { token: tokenFor(route.id), stars: R.stars.all || 0, items: its, name: R.name, text: R.text } })
      .then(function () { O.rated = true; render(true); toast('شكراً لتقييمك'); })
      .catch(function (er) { t.disabled = false; toast(er.message || 'تعذر الإرسال'); });
  }
  else if (a === 'gstar') { G.stars = Number(t.dataset.v); render(true); }
  else if (a === 'gsend') {
    if (!G.stars) { toast('اختر عدد النجوم أولاً'); return; }
    t.disabled = true;
    api('/api/reviews', { body: { name: G.name, stars: G.stars, text: G.text } })
      .then(function () { G = { name: '', stars: 0, text: '' }; toast('تم إرسال تعليقك'); return load(); })
      .then(function () { render(true); })
      .catch(function (er) { t.disabled = false; toast(er.message || 'تعذر الإرسال'); });
  }
});
function onField(e) {
  var t = e.target, f = t.dataset && t.dataset.f; if (!f) return;
  if (f === 'name' || f === 'phone' || f === 'addr' || f === 'link' || f === 'note') { F[f] = t.value; if (f !== 'note') saveForm(); updateSend(); }
  else if (f === 'ok') { F.ok = t.checked; updateSend(); }
  else if (f === 'rname') R.name = t.value;
  else if (f === 'rtext') R.text = t.value;
  else if (f === 'gname') G.name = t.value;
  else if (f === 'gtext') G.text = t.value;
}
app.addEventListener('input', onField);
app.addEventListener('change', onField);

/* ---------- boot ---------- */
render(false);
load().then(function () { onRoute(); }).catch(function () {
  app.innerHTML = '<div class="panel" style="margin-top:40px"><p style="margin:0">تعذر تحميل الصفحة. تأكد من الاتصال وأعد المحاولة.</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button></div>';
});
})();
