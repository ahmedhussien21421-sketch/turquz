(function () {
'use strict';
var app = document.getElementById('app'), toastEl = document.getElementById('toast');
var S = null;            // admin state
var tab = 'new', es = null, soundOn = false, ctx = null, ringTimer = null, wake = null;
var D = { mins: 20, unav: {}, orderId: null, rejecting: false, reason: '' };
var loginErr = '';

function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function fmt(n) { return Number(n).toLocaleString('en-US') + ' د.ع'; }
function toast(t) { toastEl.textContent = t; toastEl.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.hidden = true; }, 3000); }
function api(path, body, method) {
  var init = { method: method || (body ? 'POST' : 'GET'), headers: {} };
  if (body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
  return fetch(path, init).then(function (r) { return r.json().then(function (j) { if (!r.ok) { var e = new Error(j.message || 'error'); e.status = r.status; throw e; } return j; }); });
}
function tm(t) { var d = new Date(t); return d.toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }); }

/* ---------- sound ---------- */
function enableSound() {
  try {
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    soundOn = true; beep(0.05);
  } catch (e) { soundOn = false; }
  try { if (navigator.wakeLock) navigator.wakeLock.request('screen').then(function (w) { wake = w; }).catch(function () {}); } catch (e) {}
  try { if (window.Notification && Notification.permission === 'default') Notification.requestPermission(); } catch (e) {}
  render();
}
function tone(f, t0, dur, vol) {
  var o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'sine'; o.frequency.value = f;
  g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(ctx.destination); o.start(t0); o.stop(t0 + dur + 0.05);
}
function beep(v) { if (ctx) tone(880, ctx.currentTime, 0.2, v || 0.3); }
function ringOnce() {
  if (!ctx || !soundOn) return;
  var t = ctx.currentTime;
  [0, 0.25, 0.5, 0.75].forEach(function (d, i) { tone(i % 2 ? 1046 : 784, t + d, 0.22, 0.5); });
  try { if (navigator.vibrate) navigator.vibrate([300, 150, 300, 150, 300]); } catch (e) {}
}
function syncRing() {
  var has = !!current();
  if (has && !ringTimer) { ringOnce(); ringTimer = setInterval(ringOnce, 2200); }
  if (!has && ringTimer) { clearInterval(ringTimer); ringTimer = null; try { navigator.vibrate && navigator.vibrate(0); } catch (e) {} }
}
function current() { return S ? S.orders.filter(function (o) { return o.status === 'new'; }).sort(function (a, b) { return a.createdAt - b.createdAt; })[0] : null; }

/* ---------- web push (rings even when the page is closed) ---------- */
var pushState = 'unknown';
function b64(k) { var p = '='.repeat((4 - k.length % 4) % 4), r = atob((k + p).replace(/-/g, '+').replace(/_/g, '/')), a = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i); return a; }
function pushSupported() { return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window; }
function pushCheck() {
  if (!pushSupported()) { pushState = 'unsupported'; return Promise.resolve(); }
  return navigator.serviceWorker.register('/sw.js').then(function (reg) { return reg.pushManager.getSubscription(); }).then(function (sub) {
    pushState = Notification.permission === 'denied' ? 'denied' : (sub ? 'on' : 'off');
    if (sub) api('/api/admin/push/subscribe', { subscription: sub.toJSON() }).catch(function () {});
  }).catch(function () { pushState = 'unsupported'; });
}
function pushEnable() {
  if (!pushSupported()) { toast('المتصفح لا يدعم الإشعارات، ثبّت التطبيق على الشاشة الرئيسية'); return; }
  Notification.requestPermission().then(function (perm) {
    if (perm !== 'granted') { pushState = perm === 'denied' ? 'denied' : 'off'; render(); return; }
    return api('/api/admin/push/key').then(function (k) {
      return navigator.serviceWorker.register('/sw.js').then(function () { return navigator.serviceWorker.ready; }).then(function (reg) {
        return reg.pushManager.getSubscription().then(function (old) { return old || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(k.key) }); });
      });
    }).then(function (sub) { return api('/api/admin/push/subscribe', { subscription: sub.toJSON() }); }).then(function () { pushState = 'on'; toast('تم تفعيل إشعارات الطلبات على هذا الجهاز'); render(); });
  }).catch(function (e) { toast('تعذر التفعيل: ' + (e.message || '')); });
}

/* ---------- live ---------- */
function connect() {
  if (es) es.close();
  es = new EventSource('/api/admin/stream');
  es.addEventListener('order', function (e) {
    var o = JSON.parse(e.data); upsert(o);
    try { if (document.hidden && window.Notification && Notification.permission === 'granted') new Notification('طلب جديد #' + o.id, { body: (o.type === 'delivery' ? 'توصيل' : 'استلام من المحل') + ' · ' + fmt(o.total), tag: 'o' + o.id, requireInteraction: true }); } catch (x) {}
    render();
  });
  es.addEventListener('order-update', function (e) { upsert(JSON.parse(e.data)); render(); });
  es.addEventListener('settings', function (e) { S.settings = JSON.parse(e.data); if (tab === 'settings') return; render(); });
  es.addEventListener('menu', function (e) { var m = JSON.parse(e.data); S.menu.items.forEach(function (it) { it.lines.forEach(function (l) { if (l.sku === m.sku) { l.price = m.price; l.off = m.off; } }); }); if (tab !== 'menu') render(); });
  es.addEventListener('catalog', function () { if (!ED) refresh(); });
  es.onopen = function () { if (S) refresh(); };
}
function upsert(o) {
  var i = S.orders.findIndex(function (x) { return x.id === o.id; });
  if (i >= 0) S.orders[i] = o; else S.orders.unshift(o);
}
function refresh() { return api('/api/admin/state').then(function (s) { S = s; render(); }); }

/* ---------- views ---------- */
function loginView() {
  return '<form class="login panel" id="lf"><img class="hero-logo" src="/img/logo.jpg" alt="" width="96" height="96" style="display:block;margin:0 auto 8px"><h2 class="st" style="text-align:center">دخول الإدارة</h2>'
    + '<div class="field"><label for="u">اسم المستخدم</label><input id="u" type="text" dir="ltr" autocomplete="username" autocapitalize="off" required></div>'
    + '<div class="field"><label for="p">كلمة المرور</label><input id="p" type="password" dir="ltr" autocomplete="current-password" required></div>'
    + (loginErr ? '<div class="note bad">' + esc(loginErr) + '</div>' : '') + '<button class="btn primary block" type="submit">دخول</button></form>';
}
function oitems(o) {
  return '<ul>' + o.items.map(function (i) { return '<li' + (i.unavailable ? ' class="un"' : '') + '>' + esc(i.name) + ' × ' + i.qty + (i.unit ? ' ' + esc(i.unit) : '') + (i.unavailable ? ' (غير متوفر)' : '') + '</li>'; }).join('') + '</ul>';
}
function contact(o) {
  var loc = o.location && o.location.link ? '<a class="btn sm" href="' + esc(o.location.link) + '" target="_blank" rel="noopener">فتح موقع الزبون على الخريطة</a>' : '';
  return '<div class="meta"><div>الزبون: <b>' + esc(o.name) + '</b></div><div>الهاتف: <a href="tel:' + esc(o.phone) + '" dir="ltr"><b>' + esc(o.phone) + '</b></a></div>'
    + (o.type === 'delivery' ? '<div>العنوان: ' + esc(o.address) + '</div>' + loc : '') + (o.note ? '<div>ملاحظات: <b>' + esc(o.note) + '</b></div>' : '') + '</div>';
}
function callView(o) {
  var del = o.type === 'delivery';
  var its = o.items.map(function (i) {
    return '<label class="un"><input type="checkbox" data-un="' + esc(i.sku) + '"' + (D.unav[i.sku] ? ' checked' : '') + '><span>' + esc(i.name) + ' × ' + i.qty + (i.unit ? ' ' + esc(i.unit) : '') + ' · ' + fmt(i.total) + '</span></label>';
  }).join('');
  var mins = [10, 15, 20, 30, 45, 60, 90].map(function (m) { return '<button data-min="' + m + '" class="' + (D.mins === m ? 'on' : '') + '">' + m + ' د</button>'; }).join('');
  var more = (S.orders.filter(function (x) { return x.status === 'new'; }).length - 1);
  var body;
  if (D.rejecting) {
    body = '<div class="box"><b>سبب الرفض (يظهر للزبون)</b><div class="durs">' + ['الصنف نفد', 'المحل مشغول', 'خارج منطقة التوصيل', 'سنغلق قريباً'].map(function (r) { return '<button data-reason="' + r + '" class="' + (D.reason === r ? 'on' : '') + '">' + r + '</button>'; }).join('') + '</div>'
      + '<div class="field"><input type="text" id="rs" maxlength="120" placeholder="أو اكتب سبباً" value="' + esc(D.reason) + '" style="width:100%"></div></div>'
      + '<button class="btn big rej" data-act="rejectgo">تأكيد الرفض</button><button class="btn big rej" data-act="back">رجوع</button>';
  } else {
    body = '<div class="box"><b>الأصناف (علّم ما هو غير متوفر)</b>' + its + '</div>'
      + '<div class="box"><b>مدة إنجاز الطلب</b><div class="durs">' + mins + '</div></div>'
      + '<button class="btn big acc" data-act="accept">قبول الطلب (' + D.mins + ' دقيقة)</button><button class="btn big rej" data-act="reject">رفض الطلب</button>';
  }
  return '<div class="call" role="alertdialog" aria-label="طلب جديد"><div class="call-in"><div class="call-head"><div class="call-ring"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.6 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.6 3.6a1 1 0 0 1-.25 1z"/></svg></div>'
    + '<h2>لديك طلب جديد</h2><span class="kind' + (del ? '' : ' pick') + '">' + (del ? 'توصيل' : 'استلام من المحل') + '</span>'
    + '<div>طلب #' + o.id + ' · ' + esc(o.name) + ' · <b>' + fmt(o.total) + '</b></div>' + (more > 0 ? '<small>ومعه ' + more + ' طلب بالانتظار</small>' : '') + '</div>' + body + '</div></div>';
}
function orderCard(o) {
  var del = o.type === 'delivery', st = { new: 'جديد', accepted: 'قيد التحضير', ready: 'جاهز', completed: 'منتهي', rejected: 'مرفوض' }[o.status];
  var acts = '';
  if (o.status === 'accepted') acts = '<button class="btn primary sm" data-act="ready" data-id="' + o.id + '">الطلب جاهز</button><button class="btn sm" data-act="complete" data-id="' + o.id + '">تم التسليم</button>';
  else if (o.status === 'ready') acts = '<button class="btn primary sm" data-act="complete" data-id="' + o.id + '">تم التسليم</button>';
  var due = o.dueAt && o.status === 'accepted' ? '<div>موعد الإنجاز: <b>' + tm(o.dueAt) + '</b> (' + o.etaMinutes + ' د)</div>' : '';
  var showContact = o.status !== 'new' && o.status !== 'rejected';
  return '<article class="ocard"><header><span><b>#' + o.id + '</b> · ' + tm(o.createdAt) + '</span><span><span class="badge ' + (del ? 'del' : 'pick') + '">' + (del ? 'توصيل' : 'استلام') + '</span> <span class="badge">' + st + '</span></span></header>'
    + oitems(o) + '<div><b>' + fmt(o.total) + '</b></div>' + due + (o.status === 'rejected' && o.rejectReason ? '<div class="muted">سبب الرفض: ' + esc(o.rejectReason) + '</div>' : '')
    + (showContact ? contact(o) : '') + (o.receivedAt ? '<div class="muted">الزبون أكد الاستلام ✓</div>' : '') + (acts ? '<div class="acts">' + acts + '</div>' : '') + '</article>';
}
function ordersTab() {
  var g = { new: ['new'], prep: ['accepted'], ready: ['ready'], done: ['completed', 'rejected'] };
  var list = S.orders.filter(function (o) { return g[tab === 'orders' ? 'prep' : tab] ? g[tab === 'orders' ? 'prep' : tab].indexOf(o.status) >= 0 : false; });
  return list.length ? '<div class="list">' + list.map(orderCard).join('') + '</div>' : '<p class="muted" style="text-align:center;padding:30px 0">لا توجد طلبات هنا.</p>';
}
var ED = null; // item/category editor state
function editorView() {
  if (!ED) return '';
  var cats = S.menu.cats.map(function (c) { return '<option value="' + c.id + '"' + (ED.cat === c.id ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('');
  var img = '<div class="field"><label>الصورة</label>' + (ED.img ? '<img src="' + esc(ED.img) + '" alt="" style="width:96px;height:96px;object-fit:cover;border-radius:12px;display:block;margin-bottom:8px">' : '') + '<input type="file" accept="image/jpeg,image/png,image/webp" id="ed-file">' + (ED.up ? '<small>' + esc(ED.up) + '</small>' : '') + '</div>';
  if (ED.kind === 'cat') {
    return '<div class="panel ed"><b>' + (ED.id ? 'تعديل القسم' : 'قسم جديد') + '</b><div class="field"><label for="ed-name">اسم القسم</label><input id="ed-name" type="text" maxlength="40" value="' + esc(ED.name) + '"></div>' + img
      + '<div class="acts"><button class="btn primary" data-act="edsave">حفظ</button><button class="btn ghost" data-act="edcancel">إلغاء</button></div></div>';
  }
  var price = ED.multi
    ? '<div class="field"><label>الخيارات والأسعار (مثال: بدون جبن / مع جبن)</label>' + ED.variants.map(function (v, i) { return '<div class="arow" style="grid-template-columns:minmax(0,1fr) 110px auto"><input type="text" maxlength="30" data-vl="' + i + '" value="' + esc(v.label) + '" placeholder="الاسم"><input type="number" min="0" step="250" data-vp="' + i + '" value="' + esc(v.price) + '" placeholder="السعر"><button class="btn sm danger" data-vdel="' + i + '">×</button></div>'; }).join('') + '<button class="btn sm" data-act="vadd">+ خيار</button> <button class="btn sm ghost" data-act="single">سعر واحد فقط</button></div>'
    : '<div class="field"><label for="ed-price">السعر (دينار)</label><input id="ed-price" type="number" min="0" step="250" value="' + esc(ED.price) + '"></div><button class="btn sm ghost" data-act="multi">أكثر من خيار/سعر</button>';
  return '<div class="panel ed"><b>' + (ED.id ? 'تعديل الصنف' : 'صنف جديد') + '</b>'
    + '<div class="field"><label for="ed-name">اسم الصنف</label><input id="ed-name" type="text" maxlength="80" value="' + esc(ED.name) + '"></div>'
    + '<div class="field"><label for="ed-cat">القسم</label><select id="ed-cat">' + cats + '</select></div>'
    + '<div class="field"><label for="ed-desc">وصف قصير</label><input id="ed-desc" type="text" maxlength="200" value="' + esc(ED.desc) + '"></div>'
    + price
    + '<div class="field"><label for="ed-unit">وحدة البيع (اتركها فارغة للقطعة، أو اكتب: كيلو)</label><input id="ed-unit" type="text" maxlength="12" value="' + esc(ED.unit) + '"></div>'
    + '<div class="field"><label for="ed-step">أقل كمية/زيادة</label><select id="ed-step">' + [1, 0.5, 0.25].map(function (x) { return '<option value="' + x + '"' + (Number(ED.step) === x ? ' selected' : '') + '>' + x + '</option>'; }).join('') + '</select></div>'
    + img + '<div class="acts"><button class="btn primary" data-act="edsave">حفظ</button><button class="btn ghost" data-act="edcancel">إلغاء</button>' + (ED.id ? '<button class="btn danger" data-act="eddel">حذف الصنف</button>' : '') + '</div></div>';
}
function menuTab() {
  var full = S.me.role !== 'cashier';
  var top = full ? '<div class="acts" style="margin-bottom:8px"><button class="btn primary sm" data-act="newitem">+ صنف جديد</button><button class="btn sm" data-act="newcat">+ قسم جديد</button></div>' + editorView() : '';
  return top + S.menu.cats.map(function (c) {
    var rows = S.menu.items.filter(function (i) { return i.cat === c.id; }).map(function (it) {
      return it.lines.map(function (l, n) {
        return '<div class="arow"><div><b>' + esc(it.name) + '</b>' + (l.label ? ' <small class="muted">' + esc(l.label) + '</small>' : '') + (it.trial ? ' <span class="pill">سعر تجريبي</span>' : '') + (full && n === 0 ? ' <button class="btn sm ghost" data-edit="' + esc(it.id) + '">تعديل</button>' : '') + '</div>'
          + (full ? '<input type="number" inputmode="numeric" min="0" step="250" value="' + l.price + '" data-price="' + esc(l.sku) + '" aria-label="السعر">' : '<b>' + fmt(l.price) + '</b>')
          + '<div class="avail"><button data-av="' + esc(l.sku) + '" data-v="0" class="' + (l.off ? '' : 'on') + '">متوفر</button><button data-av="' + esc(l.sku) + '" data-v="1" class="' + (l.off ? 'on bad' : '') + '">نفد</button></div></div>';
      }).join('');
    }).join('');
    return '<h3 class="ah">' + esc(c.name) + (full ? ' <button class="btn sm ghost" data-editcat="' + esc(c.id) + '">تعديل القسم</button>' : '') + '</h3>' + rows;
  }).join('') + (full ? '<p class="muted sm">يُحفظ السعر تلقائياً عند الخروج من الخانة. الأصناف تُضاف وتُعدَّل من هنا فقط.</p>' : '');
}
function resizeAndUpload(file) {
  return new Promise(function (resolve, reject) {
    var url = URL.createObjectURL(file), im = new Image();
    im.onload = function () {
      var max = 900, r = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = Math.round(im.width * r); c.height = Math.round(im.height * r);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      c.toBlob(function (blob) {
        if (!blob) return reject(new Error('تعذر معالجة الصورة'));
        fetch('/api/admin/upload', { method: 'POST', headers: { 'Content-Type': 'image/jpeg' }, body: blob }).then(function (r) { return r.json().then(function (j) { if (!r.ok) reject(new Error(j.message || 'فشل الرفع')); else resolve(j.url); }); }).catch(reject);
      }, 'image/jpeg', 0.85);
    };
    im.onerror = function () { reject(new Error('الملف ليس صورة')); };
    im.src = url;
  });
}
function readEd() {
  var g = function (id) { var e = document.getElementById(id); return e ? e.value : ''; };
  ED.name = g('ed-name');
  if (ED.kind === 'item') {
    ED.cat = g('ed-cat'); ED.desc = g('ed-desc'); ED.unit = g('ed-unit'); ED.step = Number(g('ed-step')) || 1;
    if (ED.multi) { var vl = document.querySelectorAll('[data-vl]'), vp = document.querySelectorAll('[data-vp]'); ED.variants = [].map.call(vl, function (e, i) { return { id: ED.variants[i] && ED.variants[i].id, label: e.value, price: vp[i].value }; }); }
    else ED.price = g('ed-price');
  }
}
function settingsTab() {
  var s = S.settings;
  function seg(k, a, b) { return '<div class="seg"><button data-set="' + k + '" data-v="1" class="' + (s[k] ? 'on' : '') + '">' + a + '</button><button data-set="' + k + '" data-v="0" class="' + (!s[k] ? 'on' : '') + '">' + b + '</button></div>'; }
  var out = '<div class="panel"><b>حالة المحل</b>' + seg('open', 'نستقبل طلباتكم الآن', 'مغلقين حالياً') + '</div>'
    + '<div class="panel" style="margin-top:12px"><b>التوصيل (' + esc(s.area) + ' فقط)</b>' + seg('delivery', 'التوصيل متوفر حالياً', 'التوصيل غير متوفر حالياً') + '</div>'
    + '<div class="panel" style="margin-top:12px"><div class="field"><label for="sp">رقم المحل</label><input id="sp" type="tel" dir="ltr" value="' + esc(s.phone) + '"></div>'
    + '<div class="field"><label for="sa">عنوان المحل</label><input id="sa" type="text" value="' + esc(s.address) + '"></div>'
    + '<div class="field"><label for="st">رابط المحل في تطبيق طلبات</label><input id="st" type="url" dir="ltr" value="' + esc(s.apps.talabat) + '"></div>'
    + '<div class="field"><label for="sb">رابط المحل في تطبيق بلي</label><input id="sb" type="url" dir="ltr" value="' + esc(s.apps.bali) + '"></div>'
    + '<button class="btn primary" data-act="savesettings">حفظ</button></div>';
  out += '<h3 class="ah">كلمة المرور</h3><div class="panel"><div class="field"><label for="po">الحالية</label><input id="po" type="password" dir="ltr"></div><div class="field"><label for="pn">الجديدة (10 أحرف فأكثر)</label><input id="pn" type="password" dir="ltr"></div><button class="btn" data-act="savepw">تغيير كلمة المرور</button></div>';
  if (S.admins) {
    out += '<h3 class="ah">المسؤولون</h3><div class="panel">' + S.admins.map(function (a) { return '<div class="arow" style="grid-template-columns:1fr auto"><span><b>' + esc(a.username) + '</b> <small class="muted">' + (a.role === 'owner' ? 'المالك' : 'مسؤول') + '</small></span>' + (a.role === 'owner' ? '' : '<button class="btn sm danger" data-deladmin="' + esc(a.username) + '">حذف</button>') + '</div>'; }).join('')
      + '<div class="field"><label for="nu">إضافة مسؤول: اسم المستخدم (إنجليزي)</label><input id="nu" type="text" dir="ltr" autocapitalize="off"></div><div class="field"><label for="np">كلمة المرور (10 أحرف فأكثر)</label><input id="np" type="text" dir="ltr"></div><div class="field"><label for="nr">الصلاحية</label><select id="nr"><option value="cashier">كاشير (الطلبات وتوفر الأصناف فقط)</option><option value="admin">مسؤول (كل شيء عدا إدارة الحسابات)</option></select></div><button class="btn" data-act="addadmin">إضافة</button></div><h3 class="ah">نسخة احتياطية</h3><div class="panel"><button class="btn" data-act="backup">تنزيل نسخة احتياطية</button></div>';
  }
  return out;
}
function reviewsTab() {
  if (!S.reviews.length) return '<p class="muted" style="text-align:center;padding:30px 0">لا توجد تقييمات.</p>';
  return '<div class="list">' + S.reviews.map(function (r) {
    var hid = r.visible === false;
    return '<div class="rv"' + (hid ? ' style="opacity:.55"' : '') + '><div class="rvh"><b>' + esc(r.name) + '</b><span class="stars">' + '★'.repeat(r.stars || 0) + '</span></div>' + (r.text ? '<p>' + esc(r.text) + '</p>' : '') + (r.items && r.items.length ? '<small class="muted">' + r.items.map(function (i) { return esc(i.name) + ' ' + i.stars + '★'; }).join(' · ') + '</small>' : '')
      + '<div class="acts"><button class="btn sm" data-rv="' + r.id + '" data-v="' + (hid ? 'show' : 'hide') + '">' + (hid ? 'إظهار' : 'إخفاء') + '</button><button class="btn sm danger" data-rv="' + r.id + '" data-v="delete">حذف</button></div></div>';
  }).join('') + '</div>';
}
function dash() {
  var cnt = function (st) { return S.orders.filter(function (o) { return st.indexOf(o.status) >= 0; }).length; };
  var tabs = [['new', 'جديدة', cnt(['new'])], ['prep', 'قيد التحضير', cnt(['accepted'])], ['ready', 'جاهزة', cnt(['ready'])], ['done', 'السجل', 0], ['menu', full ? 'القائمة والأسعار' : 'توفر الأصناف', 0]].concat(full ? [['reviews', 'التقييمات', 0], ['settings', 'الإعدادات', 0]] : [['settings', 'الحالة', 0]]);
  var s = S.settings, full = S.me.role !== 'cashier';
  if (!full && (tab === 'reviews' || tab === 'settings')) tab = 'new';
  var head = '<header class="top"><span class="brand"><img class="logo" src="/img/logo.jpg" alt="" width="44" height="44"><span class="bn"><b>لوحة الكاشير</b><small>' + esc(S.me.username) + (full ? '' : ' · كاشير') + '</small></span></span><span><a class="btn ghost sm" href="/" target="_blank">الموقع</a> <button class="btn ghost sm" data-act="logout">خروج</button></span></header>';
  var snd = soundOn ? '<div class="sound on">نغمة الاتصال مفعّلة · أبقِ هذه الصفحة مفتوحة <span>🔔</span></div>' : '<div class="sound"><span>اضغط لتفعيل نغمة الاتصال (مطلوب مرة واحدة)</span><button class="btn sm primary" data-act="sound">تفعيل النغمة</button></div>';
  var pb = pushState === 'on' ? '<div class="sound on"><span>إشعارات الطلبات مفعّلة على هذا الجهاز (تصل والصفحة مغلقة)</span><button class="btn sm" data-act="pushtest">تجربة</button></div>'
    : pushState === 'denied' ? '<div class="sound"><span>الإشعارات محظورة في المتصفح. فعّلها من إعدادات الموقع ثم أعد التحميل.</span></div>'
    : pushState === 'unsupported' ? '<div class="sound"><span>للإشعارات والصفحة مغلقة: ثبّت التطبيق (إضافة إلى الشاشة الرئيسية) ثم افتحه.</span></div>'
    : pushState === 'off' ? '<div class="sound"><span>فعّل الإشعارات حتى يصلك رنين الطلب والصفحة مغلقة</span><button class="btn sm primary" data-act="pushon">تفعيل</button></div>' : '';
  var st = '<div class="chips" style="justify-content:flex-start;margin-top:8px"><span class="chip"><i class="' + (s.open ? 'g' : 'r') + '"></i>' + (s.open ? 'نستقبل الطلبات' : 'مغلقين') + '</span><span class="chip"><i class="' + (s.delivery ? 'g' : 'a') + '"></i>' + (s.delivery ? 'التوصيل متوفر' : 'التوصيل غير متوفر') + '</span></div>';
  var tb = '<nav class="tabs">' + tabs.map(function (t) { return '<button data-tab="' + t[0] + '" class="' + (tab === t[0] ? 'on' : '') + '">' + t[1] + (t[2] ? '<span class="cnt">' + t[2] + '</span>' : '') + '</button>'; }).join('') + '</nav>';
  var content = tab === 'menu' ? menuTab() : tab === 'settings' ? settingsTab() : tab === 'reviews' ? reviewsTab() : ordersTab();
  return head + snd + pb + st + tb + '<div style="margin-top:10px">' + content + '</div>' + (current() ? callView(current()) : '');
}
function render() {
  if (ED && document.getElementById('ed-name')) readEd();
  if (!S) { app.innerHTML = loginView(); return; }
  var o = current();
  if (o && D.orderId !== o.id) { D = { mins: 20, unav: {}, orderId: o.id, rejecting: false, reason: '' }; }
  var ae = document.activeElement, keep = ae && ae.id && ae.tagName === 'INPUT' ? ae.id : '';
  var y = window.scrollY;
  app.innerHTML = dash();
  if (keep) { var el = document.getElementById(keep); if (el) el.focus(); }
  window.scrollTo(0, y);
  syncRing();
  document.body.style.overflow = o ? 'hidden' : '';
}

/* ---------- events ---------- */
app.addEventListener('submit', function (e) {
  if (e.target.id !== 'lf') return;
  e.preventDefault();
  api('/api/admin/login', { username: document.getElementById('u').value, password: document.getElementById('p').value })
    .then(function () { loginErr = ''; start(); }).catch(function (er) { loginErr = er.message; render(); });
});
app.addEventListener('click', function (e) {
  var t = e.target.closest('button'); if (!t) return;
  var d = t.dataset;
  if (d.tab) { tab = d.tab; render(); return; }
  if (d.min) { D.mins = Number(d.min); render(); return; }
  if (d.reason) { D.reason = d.reason; render(); return; }
  if (d.set) { api('/api/admin/settings', (function () { var b = {}; b[d.set] = d.v === '1'; return b; })()).then(function (s) { S.settings = s; render(); }).catch(function (er) { toast(er.message); }); return; }
  if (d.av) { api('/api/admin/menu', { sku: d.av, off: d.v === '1' }).then(function (m) { S.menu.items.forEach(function (it) { it.lines.forEach(function (l) { if (l.sku === m.sku) l.off = m.off; }); }); render(); }).catch(function (er) { toast(er.message); }); return; }
  if (d.rv) { var del = d.v === 'delete'; api('/api/admin/reviews/' + d.rv + '/' + d.v, {}).then(function () { if (del) S.reviews = S.reviews.filter(function (r) { return r.id !== d.rv; }); else S.reviews.forEach(function (r) { if (r.id === d.rv) r.visible = d.v === 'show'; }); render(); }).catch(function (er) { toast(er.message); }); return; }
  if (d.deladmin) { api('/api/admin/admins/' + d.deladmin, null, 'DELETE').then(function (a) { S.admins = a; render(); }).catch(function (er) { toast(er.message); }); return; }
  if (d.edit) { var it = S.menu.items.filter(function (x) { return x.id === d.edit; })[0]; ED = { kind: 'item', id: it.id, name: it.name, cat: it.cat, desc: it.desc, unit: it.unit, step: it.step, img: it.img, multi: it.lines.length > 1 || !!it.lines[0].label, price: it.lines[0].price, variants: it.lines.map(function (l) { return { id: l.sku.split(':')[1], label: l.label, price: l.price }; }) }; render(); return; }
  if (d.editcat) { var c = S.menu.cats.filter(function (x) { return x.id === d.editcat; })[0]; ED = { kind: 'cat', id: c.id, name: c.name, img: c.img }; render(); return; }
  if (d.vdel) { readEd(); ED.variants.splice(Number(d.vdel), 1); if (!ED.variants.length) ED.variants.push({ label: '', price: '' }); render(); return; }
  var a = d.act; if (!a) return;
  var o = current();
  if (a === 'sound') enableSound();
  else if (a === 'newitem') { ED = { kind: 'item', id: null, name: '', cat: S.menu.cats[0] && S.menu.cats[0].id, desc: '', unit: '', step: 1, img: '', multi: false, price: '', variants: [{ label: '', price: '' }] }; render(); window.scrollTo(0, 0); }
  else if (a === 'newcat') { ED = { kind: 'cat', id: null, name: '', img: '' }; render(); }
  else if (a === 'edcancel') { ED = null; render(); }
  else if (a === 'multi') { readEd(); ED.multi = true; if (!ED.variants.length || !ED.variants[0].label) ED.variants = [{ label: '', price: ED.price }]; render(); }
  else if (a === 'single') { readEd(); ED.multi = false; ED.price = (ED.variants[0] || {}).price || ''; render(); }
  else if (a === 'vadd') { readEd(); ED.variants.push({ label: '', price: '' }); render(); }
  else if (a === 'eddel') { if (!ED.confirm) { ED.confirm = true; t.textContent = 'اضغط مرة ثانية للتأكيد'; return; } api('/api/admin/items/' + ED.id, null, 'DELETE').then(function (m) { S.menu = m; ED = null; render(); toast('تم حذف الصنف'); }).catch(function (er) { toast(er.message); }); }
  else if (a === 'edsave') {
    readEd(); var body, url, method = 'POST';
    if (ED.kind === 'cat') { body = { name: ED.name }; if (ED.img) body.img = ED.img; url = '/api/admin/cats' + (ED.id ? '/' + ED.id : ''); }
    else { body = { name: ED.name, cat: ED.cat, desc: ED.desc, unit: ED.unit, step: ED.step }; if (ED.img) body.img = ED.img; if (ED.multi) body.variants = ED.variants; else body.price = ED.price; url = '/api/admin/items' + (ED.id ? '/' + ED.id : ''); }
    t.disabled = true;
    api(url, body, method).then(function (m) { S.menu = m; ED = null; render(); toast('تم الحفظ'); }).catch(function (er) { t.disabled = false; toast(er.message); });
  }
  else if (a === 'backup') { window.location.href = '/api/admin/backup'; }
  else if (a === 'pushon') pushEnable();
  else if (a === 'pushtest') api('/api/admin/push/test', {}).then(function (r) { toast('أُرسلت تجربة إلى ' + r.devices + ' جهاز'); }).catch(function (er) { toast(er.message); });
  else if (a === 'logout') api('/api/admin/logout', {}).then(function () { S = null; if (es) es.close(); syncRing(); render(); });
  else if (a === 'accept' && o) {
    var un = Object.keys(D.unav).filter(function (k) { return D.unav[k]; });
    t.disabled = true;
    api('/api/admin/orders/' + o.id + '/accept', { minutes: D.mins, unavail: un }).then(function (r) { upsert(r); tab = 'prep'; render(); toast('تم قبول الطلب، تفاصيل الزبون ظاهرة الآن'); }).catch(function (er) { t.disabled = false; toast(er.message); });
  }
  else if (a === 'reject') { D.rejecting = true; render(); }
  else if (a === 'back') { D.rejecting = false; render(); }
  else if (a === 'rejectgo' && o) {
    var rs = document.getElementById('rs'); if (rs) D.reason = rs.value;
    api('/api/admin/orders/' + o.id + '/reject', { reason: D.reason }).then(function (r) { upsert(r); render(); }).catch(function (er) { toast(er.message); });
  }
  else if (a === 'ready' || a === 'complete') api('/api/admin/orders/' + d.id + '/' + a, {}).then(function (r) { upsert(r); render(); }).catch(function (er) { toast(er.message); });
  else if (a === 'savesettings') api('/api/admin/settings', { phone: val('sp'), address: val('sa'), apps: { talabat: val('st'), bali: val('sb') } }).then(function (s) { S.settings = s; toast('تم الحفظ'); render(); }).catch(function (er) { toast(er.message); });
  else if (a === 'savepw') api('/api/admin/password', { old: val('po'), new: val('pn') }).then(function () { toast('تم تغيير كلمة المرور'); render(); }).catch(function (er) { toast(er.message); });
  else if (a === 'addadmin') api('/api/admin/admins', { username: val('nu'), password: val('np'), role: val('nr') }).then(function (l) { S.admins = l; toast('تمت الإضافة'); render(); }).catch(function (er) { toast(er.message); });
});
function val(id) { var e = document.getElementById(id); return e ? e.value : ''; }
app.addEventListener('change', function (e) {
  var t = e.target;
  if (t.id === 'ed-file' && t.files && t.files[0] && ED) { readEd(); ED.up = 'جاري رفع الصورة…'; render(); resizeAndUpload(t.files[0]).then(function (u) { ED.img = u; ED.up = 'تم رفع الصورة'; render(); }).catch(function (er) { ED.up = er.message; render(); }); return; }
  if (t.dataset.un) { D.unav[t.dataset.un] = t.checked; }
  else if (t.dataset.price) { api('/api/admin/menu', { sku: t.dataset.price, price: Number(t.value) }).then(function (m) { toast('تم حفظ السعر'); S.menu.items.forEach(function (it) { it.lines.forEach(function (l) { if (l.sku === m.sku) l.price = m.price; }); }); }).catch(function (er) { toast(er.message); }); }
});
app.addEventListener('input', function (e) { if (e.target.id === 'rs') D.reason = e.target.value; });
document.addEventListener('visibilitychange', function () {
  if (!document.hidden && S) { refresh(); if (soundOn && wake === null && navigator.wakeLock) navigator.wakeLock.request('screen').then(function (w) { wake = w; }).catch(function () {}); }
});

function start() { return refresh().then(connect).then(pushCheck).then(render); }
api('/api/admin/me').then(function () { return start(); }).catch(function () { render(); });
})();
